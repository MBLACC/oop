package _26247_.question2;

// Entity base class
class Entity {
    private int id;
    private String createdDate;
    private String updatedDate;

    public Entity(int id, String createdDate, String updatedDate) {
        if (id <= 0) {
            throw new IllegalArgumentException("id must be > 0");
        }
        if (isNullOrEmpty(createdDate) || isNullOrEmpty(updatedDate)) {
            throw new IllegalArgumentException("Dates must not be null or empty");
        }
        this.id = id;
        this.createdDate = createdDate;
        this.updatedDate = updatedDate;
    }

    protected boolean isNullOrEmpty(String value) {
        return value == null || value.trim().isEmpty();
    }

    protected void validatePhone(String phone) {
        if (isNullOrEmpty(phone)) {
            throw new IllegalArgumentException("Phone must not be empty");
        }
    }

    protected void validateEmail(String email) {
        if (isNullOrEmpty(email) || !email.contains("@")) {
            throw new IllegalArgumentException("Invalid email format");
        }
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("id must be > 0");
        }
        this.id = id;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        if (isNullOrEmpty(createdDate)) {
            throw new IllegalArgumentException("createdDate must not be empty");
        }
        this.createdDate = createdDate;
    }

    public String getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(String updatedDate) {
        if (isNullOrEmpty(updatedDate)) {
            throw new IllegalArgumentException("updatedDate must not be empty");
        }
        this.updatedDate = updatedDate;
    }
}

// School
class School extends Entity {
    private String schoolName;
    private String address;
    private String phoneNumber;
    private String email;

    public School(int id, String createdDate, String updatedDate,
                  String schoolName, String address,
                  String phoneNumber, String email) {
        super(id, createdDate, updatedDate);
        if (isNullOrEmpty(schoolName) || isNullOrEmpty(address)) {
            throw new IllegalArgumentException("School name and address must not be empty");
        }
        validatePhone(phoneNumber);
        validateEmail(email);
        this.schoolName = schoolName;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.email = email;
    }

    public String getSchoolName() {
        return schoolName;
    }

    public void setSchoolName(String schoolName) {
        if (isNullOrEmpty(schoolName)) {
            throw new IllegalArgumentException("schoolName must not be empty");
        }
        this.schoolName = schoolName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        if (isNullOrEmpty(address)) {
            throw new IllegalArgumentException("address must not be empty");
        }
        this.address = address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        validatePhone(phoneNumber);
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        validateEmail(email);
        this.email = email;
    }
}

// Department
class Department extends School {
    private String departmentName;
    private String departmentCode;

    public Department(int id, String createdDate, String updatedDate,
                      String schoolName, String address, String phoneNumber, String email,
                      String departmentName, String departmentCode) {
        super(id, createdDate, updatedDate, schoolName, address, phoneNumber, email);
        if (isNullOrEmpty(departmentName)) {
            throw new IllegalArgumentException("departmentName must not be empty");
        }
        if (isNullOrEmpty(departmentCode) || departmentCode.length() < 3 ||
                !departmentCode.matches("[a-zA-Z0-9]+")) {
            throw new IllegalArgumentException("departmentCode must be alphanumeric and >= 3 chars");
        }
        this.departmentName = departmentName;
        this.departmentCode = departmentCode;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        if (isNullOrEmpty(departmentName)) {
            throw new IllegalArgumentException("departmentName must not be empty");
        }
        this.departmentName = departmentName;
    }

    public String getDepartmentCode() {
        return departmentCode;
    }

    public void setDepartmentCode(String departmentCode) {
        if (isNullOrEmpty(departmentCode) || departmentCode.length() < 3 ||
                !departmentCode.matches("[a-zA-Z0-9]+")) {
            throw new IllegalArgumentException("departmentCode must be alphanumeric and >= 3 chars");
        }
        this.departmentCode = departmentCode;
    }
}

// Teacher
class Teacher extends Department {
    private String teacherName;
    private String subject;
    private String teacherEmail;
    private String phone;

    public Teacher(int id, String createdDate, String updatedDate,
                   String schoolName, String address, String phoneNumber, String email,
                   String departmentName, String departmentCode,
                   String teacherName, String subject,
                   String teacherEmail, String phone) {
        super(id, createdDate, updatedDate, schoolName, address, phoneNumber, email,
              departmentName, departmentCode);
        if (isNullOrEmpty(teacherName) || isNullOrEmpty(subject)) {
            throw new IllegalArgumentException("Teacher name and subject must not be empty");
        }
        validateEmail(teacherEmail);
        validatePhone(phone);
        this.teacherName = teacherName;
        this.subject = subject;
        this.teacherEmail = teacherEmail;
        this.phone = phone;
    }

    public String getTeacherName() {
        return teacherName;
    }

    public void setTeacherName(String teacherName) {
        if (isNullOrEmpty(teacherName)) {
            throw new IllegalArgumentException("teacherName must not be empty");
        }
        this.teacherName = teacherName;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        if (isNullOrEmpty(subject)) {
            throw new IllegalArgumentException("subject must not be empty");
        }
        this.subject = subject;
    }

    public String getTeacherEmail() {
        return teacherEmail;
    }

    public void setTeacherEmail(String teacherEmail) {
        validateEmail(teacherEmail);
        this.teacherEmail = teacherEmail;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        validatePhone(phone);
        this.phone = phone;
    }
}

// Student
class Student extends Teacher {
    private String studentName;
    private int rollNumber;
    private String grade;
    private String contactNumber;

    public Student(int id, String createdDate, String updatedDate,
                   String schoolName, String address, String phoneNumber, String email,
                   String departmentName, String departmentCode,
                   String teacherName, String subject,
                   String teacherEmail, String phone,
                   String studentName, int rollNumber, String grade, String contactNumber) {
        super(id, createdDate, updatedDate, schoolName, address, phoneNumber, email,
              departmentName, departmentCode,
              teacherName, subject, teacherEmail, phone);
        if (isNullOrEmpty(studentName)) {
            throw new IllegalArgumentException("studentName must not be empty");
        }
        if (rollNumber <= 0) {
            throw new IllegalArgumentException("rollNumber must be > 0");
        }
        if (isNullOrEmpty(grade)) {
            throw new IllegalArgumentException("grade must not be empty");
        }
        validatePhone(contactNumber);
        this.studentName = studentName;
        this.rollNumber = rollNumber;
        this.grade = grade;
        this.contactNumber = contactNumber;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        if (isNullOrEmpty(studentName)) {
            throw new IllegalArgumentException("studentName must not be empty");
        }
        this.studentName = studentName;
    }

    public int getRollNumber() {
        return rollNumber;
    }

    public void setRollNumber(int rollNumber) {
        if (rollNumber <= 0) {
            throw new IllegalArgumentException("rollNumber must be > 0");
        }
        this.rollNumber = rollNumber;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        if (isNullOrEmpty(grade)) {
            throw new IllegalArgumentException("grade must not be empty");
        }
        this.grade = grade;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        validatePhone(contactNumber);
        this.contactNumber = contactNumber;
    }
}

// Course
class Course extends Student {
    private String courseName;
    private String courseCode;
    private int creditHours;

    public Course(int id, String createdDate, String updatedDate,
                  String schoolName, String address, String phoneNumber, String email,
                  String departmentName, String departmentCode,
                  String teacherName, String subject,
                  String teacherEmail, String phone,
                  String studentName, int rollNumber, String grade, String contactNumber,
                  String courseName, String courseCode, int creditHours) {
        super(id, createdDate, updatedDate, schoolName, address, phoneNumber, email,
              departmentName, departmentCode,
              teacherName, subject, teacherEmail, phone,
              studentName, rollNumber, grade, contactNumber);
        if (isNullOrEmpty(courseName)) {
            throw new IllegalArgumentException("courseName must not be empty");
        }
        if (isNullOrEmpty(courseCode)) {
            throw new IllegalArgumentException("courseCode must not be empty");
        }
        if (creditHours <= 0) {
            throw new IllegalArgumentException("creditHours must be > 0");
        }
        this.courseName = courseName;
        this.courseCode = courseCode;
        this.creditHours = creditHours;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        if (isNullOrEmpty(courseName)) {
            throw new IllegalArgumentException("courseName must not be empty");
        }
        this.courseName = courseName;
    }

    public String getCourseCode() {
        return courseCode;
    }

    public void setCourseCode(String courseCode) {
        if (isNullOrEmpty(courseCode)) {
            throw new IllegalArgumentException("courseCode must not be empty");
        }
        this.courseCode = courseCode;
    }

    public int getCreditHours() {
        return creditHours;
    }

    public void setCreditHours(int creditHours) {
        if (creditHours <= 0) {
            throw new IllegalArgumentException("creditHours must be > 0");
        }
        this.creditHours = creditHours;
    }
}

// Exam
class Exam extends Course {
    private String examName;
    private double maxMarks;
    private String examDate;

    public Exam(int id, String createdDate, String updatedDate,
                String schoolName, String address, String phoneNumber, String email,
                String departmentName, String departmentCode,
                String teacherName, String subject,
                String teacherEmail, String phone,
                String studentName, int rollNumber, String grade, String contactNumber,
                String courseName, String courseCode, int creditHours,
                String examName, double maxMarks, String examDate) {
        super(id, createdDate, updatedDate, schoolName, address, phoneNumber, email,
              departmentName, departmentCode,
              teacherName, subject, teacherEmail, phone,
              studentName, rollNumber, grade, contactNumber,
              courseName, courseCode, creditHours);
        if (isNullOrEmpty(examName) || isNullOrEmpty(examDate)) {
            throw new IllegalArgumentException("examName and examDate must not be empty");
        }
        if (maxMarks <= 0) {
            throw new IllegalArgumentException("maxMarks must be > 0");
        }
        this.examName = examName;
        this.maxMarks = maxMarks;
        this.examDate = examDate;
    }

    public String getExamName() {
        return examName;
    }

    public void setExamName(String examName) {
        if (isNullOrEmpty(examName)) {
            throw new IllegalArgumentException("examName must not be empty");
        }
        this.examName = examName;
    }

    public double getMaxMarks() {
        return maxMarks;
    }

    public void setMaxMarks(double maxMarks) {
        if (maxMarks <= 0) {
            throw new IllegalArgumentException("maxMarks must be > 0");
        }
        this.maxMarks = maxMarks;
    }

    public String getExamDate() {
        return examDate;
    }

    public void setExamDate(String examDate) {
        if (isNullOrEmpty(examDate)) {
            throw new IllegalArgumentException("examDate must not be empty");
        }
        this.examDate = examDate;
    }
}

// Result
class Result extends Exam {
    private double obtainedMarks;
    private String remarks;

    public Result(int id, String createdDate, String updatedDate,
                  String schoolName, String address, String phoneNumber, String email,
                  String departmentName, String departmentCode,
                  String teacherName, String subject,
                  String teacherEmail, String phone,
                  String studentName, int rollNumber, String grade, String contactNumber,
                  String courseName, String courseCode, int creditHours,
                  String examName, double maxMarks, String examDate,
                  double obtainedMarks, String remarks) {
        super(id, createdDate, updatedDate, schoolName, address, phoneNumber, email,
              departmentName, departmentCode,
              teacherName, subject, teacherEmail, phone,
              studentName, rollNumber, grade, contactNumber,
              courseName, courseCode, creditHours,
              examName, maxMarks, examDate);
        if (obtainedMarks < 0) {
            throw new IllegalArgumentException("obtainedMarks must be >= 0");
        }
        if (isNullOrEmpty(remarks)) {
            throw new IllegalArgumentException("remarks must not be empty");
        }
        this.obtainedMarks = obtainedMarks;
        this.remarks = remarks;
    }

    public double getObtainedMarks() {
        return obtainedMarks;
    }

    public void setObtainedMarks(double obtainedMarks) {
        if (obtainedMarks < 0) {
            throw new IllegalArgumentException("obtainedMarks must be >= 0");
        }
        this.obtainedMarks = obtainedMarks;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        if (isNullOrEmpty(remarks)) {
            throw new IllegalArgumentException("remarks must not be empty");
        }
        this.remarks = remarks;
    }
}

// Fee
class Fee extends Result {
    private double tuitionFee;
    private double examFee;
    private double totalFee;

    public Fee(int id, String createdDate, String updatedDate,
               String schoolName, String address, String phoneNumber, String email,
               String departmentName, String departmentCode,
               String teacherName, String subject,
               String teacherEmail, String phone,
               String studentName, int rollNumber, String grade, String contactNumber,
               String courseName, String courseCode, int creditHours,
               String examName, double maxMarks, String examDate,
               double obtainedMarks, String remarks,
               double tuitionFee, double examFee) {
        super(id, createdDate, updatedDate, schoolName, address, phoneNumber, email,
              departmentName, departmentCode,
              teacherName, subject, teacherEmail, phone,
              studentName, rollNumber, grade, contactNumber,
              courseName, courseCode, creditHours,
              examName, maxMarks, examDate,
              obtainedMarks, remarks);
        if (tuitionFee <= 0 || examFee <= 0) {
            throw new IllegalArgumentException("tuitionFee and examFee must be > 0");
        }
        this.tuitionFee = tuitionFee;
        this.examFee = examFee;
        this.totalFee = 0.0; // will be set in StudentRecord
    }

    public double getTuitionFee() {
        return tuitionFee;
    }

    public void setTuitionFee(double tuitionFee) {
        if (tuitionFee <= 0) {
            throw new IllegalArgumentException("tuitionFee must be > 0");
        }
        this.tuitionFee = tuitionFee;
    }

    public double getExamFee() {
        return examFee;
    }

    public void setExamFee(double examFee) {
        if (examFee <= 0) {
            throw new IllegalArgumentException("examFee must be > 0");
        }
        this.examFee = examFee;
    }

    public double getTotalFee() {
        return totalFee;
    }

    public void setTotalFee(double totalFee) {
        if (totalFee <= 0) {
            throw new IllegalArgumentException("totalFee must be > 0");
        }
        this.totalFee = totalFee;
    }
}

// Final class StudentRecord
public final class StudentRecord extends Fee {

    public StudentRecord(int id, String createdDate, String updatedDate,
                         String schoolName, String address, String phoneNumber, String email,
                         String departmentName, String departmentCode,
                         String teacherName, String subject,
                         String teacherEmail, String phone,
                         String studentName, int rollNumber, String grade, String contactNumber,
                         String courseName, String courseCode, int creditHours,
                         String examName, double maxMarks, String examDate,
                         double obtainedMarks, String remarks,
                         double tuitionFee, double examFee) {
        super(id, createdDate, updatedDate, schoolName, address, phoneNumber, email,
              departmentName, departmentCode,
              teacherName, subject, teacherEmail, phone,
              studentName, rollNumber, grade, contactNumber,
              courseName, courseCode, creditHours,
              examName, maxMarks, examDate,
              obtainedMarks, remarks,
              tuitionFee, examFee);
    }

    // calculateAverageMarks() = (obtainedMarks / maxMarks)  d 100
    public double calculateAverageMarks() {
        double avg = (getObtainedMarks() / getMaxMarks()) * 100.0;
        return avg;
    }

    public double calculateTotalFee() {
        double total = getTuitionFee() + getExamFee();
        setTotalFee(total);
        return total;
    }
}
