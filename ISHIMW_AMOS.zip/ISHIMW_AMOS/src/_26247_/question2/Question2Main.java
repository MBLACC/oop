package _26247_.question2;

import java.util.Scanner;

public class Question2Main {

    private static final String STUDENT_ID = "26247";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int maxAttempts = 3;

        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            try {
                runProgram(scanner);
                break;
            } catch (IllegalArgumentException ex) {
                printlnWithId("ERROR: " + ex.getMessage());
                if (attempt == maxAttempts) {
                    printlnWithId("Maximum attempts (" + maxAttempts + ") reached. Exiting program.");
                } else {
                    printlnWithId("Please re-enter all details carefully. Attempt "
                            + (attempt + 1) + " of " + maxAttempts + ".");
                }
            }
        }

        scanner.close();
    }

    private static void runProgram(Scanner scanner) {
        printlnWithId("=== Question 2: School Management System ===");

        int entityId = readPositiveInt(scanner, "Enter Entity ID (integer > 0): ");
        String createdDate = readNonEmptyString(scanner, "Enter Created Date (e.g., 2025-11-22): ");
        String updatedDate = readNonEmptyString(scanner, "Enter Updated Date (e.g., 2025-11-22): ");

        String schoolName = readNonEmptyString(scanner, "Enter School Name (non-empty text): ");
        String schoolAddress = readNonEmptyString(scanner, "Enter School Address (non-empty text): ");
        String schoolPhone = readNonEmptyString(scanner, "Enter School Phone Number (non-empty text): ");
        String schoolEmail = readEmail(scanner, "Enter School Email (must contain @): ");

        String departmentName = readNonEmptyString(scanner, "Enter Department Name (non-empty text): ");
        String departmentCode = readAlphaNumericMinLen(scanner,
                "Enter Department Code (alphanumeric, at least 3 characters): ", 3);

        String teacherName = readNonEmptyString(scanner, "Enter Teacher Name (non-empty text): ");
        String subject = readNonEmptyString(scanner, "Enter Teacher Subject (non-empty text): ");
        String teacherEmail = readEmail(scanner, "Enter Teacher Email (must contain @): ");
        String teacherPhone = readNonEmptyString(scanner, "Enter Teacher Phone (non-empty text): ");

        String studentName = readNonEmptyString(scanner, "Enter Student Name (non-empty text): ");
        int rollNumber = readPositiveInt(scanner, "Enter Student Roll Number (integer > 0): ");
        String grade = readNonEmptyString(scanner, "Enter Student Grade (non-empty text): ");
        String studentContact = readNonEmptyString(scanner, "Enter Student Contact Number (non-empty text): ");

        String courseName = readNonEmptyString(scanner, "Enter Course Name (non-empty text): ");
        String courseCode = readNonEmptyString(scanner, "Enter Course Code (non-empty text): ");
        int creditHours = readPositiveInt(scanner, "Enter Credit Hours (integer > 0): ");

        String examName = readNonEmptyString(scanner, "Enter Exam Name (non-empty text): ");
        double maxMarks = readPositiveDouble(scanner, "Enter Max Marks (number > 0): ");
        String examDate = readNonEmptyString(scanner, "Enter Exam Date (e.g., 2025-11-22): ");

        double obtainedMarks = readNonNegativeDouble(scanner,
                "Enter Obtained Marks (number >= 0): ");
        String remarks = readNonEmptyString(scanner, "Enter Remarks (non-empty text): ");

        double tuitionFee = readPositiveDouble(scanner, "Enter Tuition Fee (number > 0): ");
        double examFee = readPositiveDouble(scanner, "Enter Exam Fee (number > 0): ");

        StudentRecord record = new StudentRecord(
                entityId, createdDate, updatedDate,
                schoolName, schoolAddress, schoolPhone, schoolEmail,
                departmentName, departmentCode,
                teacherName, subject, teacherEmail, teacherPhone,
                studentName, rollNumber, grade, studentContact,
                courseName, courseCode, creditHours,
                examName, maxMarks, examDate,
                obtainedMarks, remarks,
                tuitionFee, examFee
        );

        double totalFee = record.calculateTotalFee();
        double averageMarks = record.calculateAverageMarks();

        printlnWithId("=== Student Record Summary ===");
        printlnWithId("Entity ID: " + record.getId());
        printlnWithId("School: " + record.getSchoolName() + ", " + record.getAddress());
        printlnWithId("Department: " + record.getDepartmentName() + " (" + record.getDepartmentCode() + ")");
        printlnWithId("Teacher: " + record.getTeacherName() + " - " + record.getSubject());
        printlnWithId("Student: " + record.getStudentName() + " (Roll: " + record.getRollNumber()
                + ", Grade: " + record.getGrade() + ")");
        printlnWithId("Course: " + record.getCourseName() + " (" + record.getCourseCode() + ", "
                + record.getCreditHours() + " credits)");
        printlnWithId("Exam: " + record.getExamName() + " on " + record.getExamDate());
        printlnWithId("Marks: " + record.getObtainedMarks() + "/" + record.getMaxMarks()
                + " (" + averageMarks + "%)");
        printlnWithId("Remarks: " + record.getRemarks());
        printlnWithId("Tuition Fee: " + record.getTuitionFee());
        printlnWithId("Exam Fee: " + record.getExamFee());
        printlnWithId("Total Fee: " + totalFee);
    }

    private static void printlnWithId(String msg) {
        System.out.println(msg + " [" + STUDENT_ID + "]");
    }

    private static void printWithId(String msg) {
        System.out.print(msg + " [" + STUDENT_ID + "] ");
    }

    private static int readPositiveInt(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            if (!scanner.hasNextInt()) {
                scanner.nextLine();
                printlnWithId("Invalid input: please enter a whole number > 0. Attempts left: " + (3 - attempt));
                continue;
            }
            int value = scanner.nextInt();
            scanner.nextLine();
            if (value > 0) {
                return value;
            }
            printlnWithId("Value must be > 0. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return 0;
    }

    private static double readPositiveDouble(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            if (!scanner.hasNextDouble()) {
                scanner.nextLine();
                printlnWithId("Invalid input: please enter a number > 0. Attempts left: " + (3 - attempt));
                continue;
            }
            double value = scanner.nextDouble();
            scanner.nextLine();
            if (value > 0) {
                return value;
            }
            printlnWithId("Value must be > 0. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return 0.0;
    }

    private static double readNonNegativeDouble(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            if (!scanner.hasNextDouble()) {
                scanner.nextLine();
                printlnWithId("Invalid input: please enter a number >= 0. Attempts left: " + (3 - attempt));
                continue;
            }
            double value = scanner.nextDouble();
            scanner.nextLine();
            if (value >= 0) {
                return value;
            }
            printlnWithId("Value must be >= 0. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return 0.0;
    }

    private static String readNonEmptyString(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            String value = scanner.nextLine();
            if (value != null && !value.trim().isEmpty()) {
                return value.trim();
            }
            printlnWithId("Input must not be empty. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return null;
    }

    private static String readEmail(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            String value = scanner.nextLine().trim();
            if (!value.isEmpty() && value.contains("@")) {
                return value;
            }
            printlnWithId("Invalid email: must contain '@'. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return null;
    }

    private static String readAlphaNumericMinLen(Scanner scanner, String prompt, int minLen) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            String value = scanner.nextLine().trim();
            if (value.length() >= minLen && value.matches("[a-zA-Z0-9]+")) {
                return value;
            }
            printlnWithId("Invalid code: must be alphanumeric and at least "
                    + minLen + " characters. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return null;
    }
}
