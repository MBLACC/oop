package _26247_.question3;

import java.util.Scanner;

public class Question3Main {

    private static final String STUDENT_ID = "26247";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int maxAttempts = 3;

        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            try {
                runProgram(scanner);
                break;
            } catch (IllegalArgumentException ex) {
                printlnWithId("ERROR: " + ex.getMessage());
                if (attempt == maxAttempts) {
                    printlnWithId("Maximum attempts (" + maxAttempts + ") reached. Exiting program.");
                } else {
                    printlnWithId("Please re-enter all details carefully. Attempt "
                            + (attempt + 1) + " of " + maxAttempts + ".");
                }
            }
        }

        scanner.close();
    }

    private static void runProgram(Scanner scanner) {
        printlnWithId("=== Question 3: Employee Payroll System ===");

        int entityId = readPositiveInt(scanner, "Enter Entity ID (integer > 0): ");
        String createdDate = readNonEmptyString(scanner, "Enter Created Date (e.g., 2025-11-22): ");
        String updatedDate = readNonEmptyString(scanner, "Enter Updated Date (e.g., 2025-11-22): ");

        String companyName = readNonEmptyString(scanner, "Enter Company Name (non-empty text): ");
        String companyAddress = readNonEmptyString(scanner, "Enter Company Address (non-empty text): ");
        String companyPhone = readPhone10(scanner, "Enter Company Phone Number (exactly 10 digits): ");
        String companyEmail = readEmail(scanner, "Enter Company Email (must contain @): ");

        String departmentName = readNonEmptyString(scanner, "Enter Department Name (non-empty text): ");
        String departmentCode = readAlphaNumericMinLen(scanner,
                "Enter Department Code (alphanumeric, at least 3 characters): ", 3);

        String managerName = readNonEmptyString(scanner, "Enter Manager Name (non-empty text): ");
        String managerEmail = readEmail(scanner, "Enter Manager Email (must contain @): ");
        String managerPhone = readPhone10(scanner, "Enter Manager Phone (exactly 10 digits): ");

        String employeeName = readNonEmptyString(scanner, "Enter Employee Name (non-empty text): ");
        int employeeId = readPositiveInt(scanner, "Enter Employee ID (integer > 0): ");
        String designation = readNonEmptyString(scanner, "Enter Employee Designation (non-empty text): ");
        String employeeContact = readPhone10(scanner, "Enter Employee Contact Number (exactly 10 digits): ");

        int totalDays = readNonNegativeInt(scanner, "Enter Total Days (integer >= 0): ");
        int presentDays = readNonNegativeInt(scanner,
                "Enter Present Days (integer >= 0 and <= Total Days): ");
        int leaveDays = readNonNegativeInt(scanner, "Enter Leave Days (integer >= 0): ");

        double housingAllowance = readNonNegativeDouble(scanner,
                "Enter Housing Allowance (number >= 0): ");
        double transportAllowance = readNonNegativeDouble(scanner,
                "Enter Transport Allowance (number >= 0): ");

        double taxDeduction = readNonNegativeDouble(scanner,
                "Enter Tax Deduction (number >= 0): ");
        double loanDeduction = readNonNegativeDouble(scanner,
                "Enter Loan Deduction (number >= 0): ");

        double basicSalary = readPositiveDouble(scanner,
                "Enter Basic Salary (number > 0): ");

        if (presentDays > totalDays) {
            throw new IllegalArgumentException("Present days must not be greater than total days.");
        }

        PayrollRecord record = new PayrollRecord(
                entityId, createdDate, updatedDate,
                companyName, companyAddress, companyPhone, companyEmail,
                departmentName, departmentCode,
                managerName, managerEmail, managerPhone,
                employeeName, employeeId, designation, employeeContact,
                totalDays, presentDays, leaveDays,
                housingAllowance, transportAllowance,
                taxDeduction, loanDeduction,
                basicSalary
        );

        double netSalary = record.calculateNetSalary();

        printlnWithId("=== Payroll Record Summary ===");
        printlnWithId("Entity ID: " + record.getId());
        printlnWithId("Company: " + record.getCompanyName() + ", " + record.getAddress());
        printlnWithId("Department: " + record.getDepartmentName() + " (" + record.getDepartmentCode() + ")");
        printlnWithId("Manager: " + record.getManagerName());
        printlnWithId("Employee: " + record.getEmployeeName() + " (ID: " + record.getEmployeeId()
                + ", " + record.getDesignation() + ")");
        printlnWithId("Total Days: " + record.getTotalDays() + ", Present: " + record.getPresentDays()
                + ", Leave: " + record.getLeaveDays());
        printlnWithId("Housing Allowance: " + record.getHousingAllowance());
        printlnWithId("Transport Allowance: " + record.getTransportAllowance());
        printlnWithId("Tax Deduction: " + record.getTaxDeduction());
        printlnWithId("Loan Deduction: " + record.getLoanDeduction());
        printlnWithId("Basic Salary: " + record.getBasicSalary());
        printlnWithId("Gross Salary: " + record.getGrossSalary());
        printlnWithId("Net Salary: " + netSalary);
    }

    private static void printlnWithId(String msg) {
        System.out.println(msg + " [" + STUDENT_ID + "]");
    }

    private static void printWithId(String msg) {
        System.out.print(msg + " [" + STUDENT_ID + "] ");
    }

    private static int readPositiveInt(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            if (!scanner.hasNextInt()) {
                scanner.nextLine();
                printlnWithId("Invalid input: please enter a whole number > 0. Attempts left: " + (3 - attempt));
                continue;
            }
            int value = scanner.nextInt();
            scanner.nextLine();
            if (value > 0) {
                return value;
            }
            printlnWithId("Value must be > 0. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return 0;
    }

    private static int readNonNegativeInt(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            if (!scanner.hasNextInt()) {
                scanner.nextLine();
                printlnWithId("Invalid input: please enter a whole number >= 0. Attempts left: " + (3 - attempt));
                continue;
            }
            int value = scanner.nextInt();
            scanner.nextLine();
            if (value >= 0) {
                return value;
            }
            printlnWithId("Value must be >= 0. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return 0;
    }

    private static double readPositiveDouble(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            if (!scanner.hasNextDouble()) {
                scanner.nextLine();
                printlnWithId("Invalid input: please enter a number > 0. Attempts left: " + (3 - attempt));
                continue;
            }
            double value = scanner.nextDouble();
            scanner.nextLine();
            if (value > 0) {
                return value;
            }
            printlnWithId("Value must be > 0. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return 0.0;
    }

    private static double readNonNegativeDouble(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            if (!scanner.hasNextDouble()) {
                scanner.nextLine();
                printlnWithId("Invalid input: please enter a number >= 0. Attempts left: " + (3 - attempt));
                continue;
            }
            double value = scanner.nextDouble();
            scanner.nextLine();
            if (value >= 0) {
                return value;
            }
            printlnWithId("Value must be >= 0. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return 0.0;
    }

    private static String readNonEmptyString(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            String value = scanner.nextLine();
            if (value != null && !value.trim().isEmpty()) {
                return value.trim();
            }
            printlnWithId("Input must not be empty. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return null;
    }

    private static String readEmail(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            String value = scanner.nextLine().trim();
            if (!value.isEmpty() && value.contains("@")) {
                return value;
            }
            printlnWithId("Invalid email: must contain '@'. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return null;
    }

    private static String readPhone10(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            String value = scanner.nextLine().trim();
            if (value.matches("\\d{10}")) {
                return value;
            }
            printlnWithId("Phone number must be exactly 10 digits (0-9). Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return null;
    }

    private static String readAlphaNumericMinLen(Scanner scanner, String prompt, int minLen) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            String value = scanner.nextLine().trim();
            if (value.length() >= minLen && value.matches("[a-zA-Z0-9]+")) {
                return value;
            }
            printlnWithId("Invalid code: must be alphanumeric and at least "
                    + minLen + " characters. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return null;
    }
}
