package _26247_.question3;

// Entity base class
class Entity {
    private int id;
    private String createdDate;
    private String updatedDate;

    public Entity(int id, String createdDate, String updatedDate) {
        if (id <= 0) {
            throw new IllegalArgumentException("id must be > 0");
        }
        if (isNullOrEmpty(createdDate) || isNullOrEmpty(updatedDate)) {
            throw new IllegalArgumentException("Dates must not be null or empty");
        }
        this.id = id;
        this.createdDate = createdDate;
        this.updatedDate = updatedDate;
    }

    protected boolean isNullOrEmpty(String value) {
        return value == null || value.trim().isEmpty();
    }

    protected void validatePhone10(String phone) {
        if (phone == null || !phone.matches("\\d{10}")) {
            throw new IllegalArgumentException("Phone must be exactly 10 digits");
        }
    }

    protected void validateEmail(String email) {
        if (isNullOrEmpty(email) || !email.contains("@")) {
            throw new IllegalArgumentException("Invalid email format");
        }
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("id must be > 0");
        }
        this.id = id;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        if (isNullOrEmpty(createdDate)) {
            throw new IllegalArgumentException("createdDate must not be empty");
        }
        this.createdDate = createdDate;
    }

    public String getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(String updatedDate) {
        if (isNullOrEmpty(updatedDate)) {
            throw new IllegalArgumentException("updatedDate must not be empty");
        }
        this.updatedDate = updatedDate;
    }
}

// Company
class Company extends Entity {
    private String companyName;
    private String address;
    private String phoneNumber;
    private String email;

    public Company(int id, String createdDate, String updatedDate,
                   String companyName, String address,
                   String phoneNumber, String email) {
        super(id, createdDate, updatedDate);
        if (isNullOrEmpty(companyName) || isNullOrEmpty(address)) {
            throw new IllegalArgumentException("Company name and address must not be empty");
        }
        validatePhone10(phoneNumber);
        validateEmail(email);
        this.companyName = companyName;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.email = email;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        if (isNullOrEmpty(companyName)) {
            throw new IllegalArgumentException("companyName must not be empty");
        }
        this.companyName = companyName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        if (isNullOrEmpty(address)) {
            throw new IllegalArgumentException("address must not be empty");
        }
        this.address = address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        validatePhone10(phoneNumber);
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        validateEmail(email);
        this.email = email;
    }
}

// Department
class Department extends Company {
    private String departmentName;
    private String departmentCode;

    public Department(int id, String createdDate, String updatedDate,
                      String companyName, String address, String phoneNumber, String email,
                      String departmentName, String departmentCode) {
        super(id, createdDate, updatedDate, companyName, address, phoneNumber, email);
        if (isNullOrEmpty(departmentName)) {
            throw new IllegalArgumentException("departmentName must not be empty");
        }
        if (isNullOrEmpty(departmentCode) || departmentCode.length() < 3 ||
                !departmentCode.matches("[a-zA-Z0-9]+")) {
            throw new IllegalArgumentException("departmentCode must be alphanumeric and >= 3 chars");
        }
        this.departmentName = departmentName;
        this.departmentCode = departmentCode;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        if (isNullOrEmpty(departmentName)) {
            throw new IllegalArgumentException("departmentName must not be empty");
        }
        this.departmentName = departmentName;
    }

    public String getDepartmentCode() {
        return departmentCode;
    }

    public void setDepartmentCode(String departmentCode) {
        if (isNullOrEmpty(departmentCode) || departmentCode.length() < 3 ||
                !departmentCode.matches("[a-zA-Z0-9]+")) {
            throw new IllegalArgumentException("departmentCode must be alphanumeric and >= 3 chars");
        }
        this.departmentCode = departmentCode;
    }
}

// Manager
class Manager extends Department {
    private String managerName;
    private String managerEmail;
    private String phone;

    public Manager(int id, String createdDate, String updatedDate,
                   String companyName, String address, String phoneNumber, String email,
                   String departmentName, String departmentCode,
                   String managerName, String managerEmail, String phone) {
        super(id, createdDate, updatedDate, companyName, address, phoneNumber, email,
              departmentName, departmentCode);
        if (isNullOrEmpty(managerName)) {
            throw new IllegalArgumentException("managerName must not be empty");
        }
        validateEmail(managerEmail);
        validatePhone10(phone);
        this.managerName = managerName;
        this.managerEmail = managerEmail;
        this.phone = phone;
    }

    public String getManagerName() {
        return managerName;
    }

    public void setManagerName(String managerName) {
        if (isNullOrEmpty(managerName)) {
            throw new IllegalArgumentException("managerName must not be empty");
        }
        this.managerName = managerName;
    }

    public String getManagerEmail() {
        return managerEmail;
    }

    public void setManagerEmail(String managerEmail) {
        validateEmail(managerEmail);
        this.managerEmail = managerEmail;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        validatePhone10(phone);
        this.phone = phone;
    }
}

// Employee
class Employee extends Manager {
    private String employeeName;
    private int employeeId;
    private String designation;
    private String contactNumber;

    public Employee(int id, String createdDate, String updatedDate,
                    String companyName, String address, String phoneNumber, String email,
                    String departmentName, String departmentCode,
                    String managerName, String managerEmail, String phone,
                    String employeeName, int employeeId, String designation, String contactNumber) {
        super(id, createdDate, updatedDate, companyName, address, phoneNumber, email,
              departmentName, departmentCode,
              managerName, managerEmail, phone);
        if (isNullOrEmpty(employeeName) || isNullOrEmpty(designation)) {
            throw new IllegalArgumentException("Employee name and designation must not be empty");
        }
        if (employeeId <= 0) {
            throw new IllegalArgumentException("employeeId must be > 0");
        }
        validatePhone10(contactNumber);
        this.employeeName = employeeName;
        this.employeeId = employeeId;
        this.designation = designation;
        this.contactNumber = contactNumber;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        if (isNullOrEmpty(employeeName)) {
            throw new IllegalArgumentException("employeeName must not be empty");
        }
        this.employeeName = employeeName;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        if (employeeId <= 0) {
            throw new IllegalArgumentException("employeeId must be > 0");
        }
        this.employeeId = employeeId;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        if (isNullOrEmpty(designation)) {
            throw new IllegalArgumentException("designation must not be empty");
        }
        this.designation = designation;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        validatePhone10(contactNumber);
        this.contactNumber = contactNumber;
    }
}

// Attendance
class Attendance extends Employee {
    private int totalDays;
    private int presentDays;
    private int leaveDays;

    public Attendance(int id, String createdDate, String updatedDate,
                      String companyName, String address, String phoneNumber, String email,
                      String departmentName, String departmentCode,
                      String managerName, String managerEmail, String phone,
                      String employeeName, int employeeId, String designation, String contactNumber,
                      int totalDays, int presentDays, int leaveDays) {
        super(id, createdDate, updatedDate, companyName, address, phoneNumber, email,
              departmentName, departmentCode,
              managerName, managerEmail, phone,
              employeeName, employeeId, designation, contactNumber);
        if (totalDays < 0 || presentDays < 0 || leaveDays < 0) {
            throw new IllegalArgumentException("Days must be >= 0");
        }
        if (presentDays > totalDays) {
            throw new IllegalArgumentException("presentDays must be <= totalDays");
        }
        this.totalDays = totalDays;
        this.presentDays = presentDays;
        this.leaveDays = leaveDays;
    }

    public int getTotalDays() {
        return totalDays;
    }

    public void setTotalDays(int totalDays) {
        if (totalDays < 0) {
            throw new IllegalArgumentException("totalDays must be >= 0");
        }
        this.totalDays = totalDays;
    }

    public int getPresentDays() {
        return presentDays;
    }

    public void setPresentDays(int presentDays) {
        if (presentDays < 0 || presentDays > totalDays) {
            throw new IllegalArgumentException("presentDays must be between 0 and totalDays");
        }
        this.presentDays = presentDays;
    }

    public int getLeaveDays() {
        return leaveDays;
    }

    public void setLeaveDays(int leaveDays) {
        if (leaveDays < 0) {
            throw new IllegalArgumentException("leaveDays must be >= 0");
        }
        this.leaveDays = leaveDays;
    }
}

// Allowance
class Allowance extends Attendance {
    private double housingAllowance;
    private double transportAllowance;

    public Allowance(int id, String createdDate, String updatedDate,
                     String companyName, String address, String phoneNumber, String email,
                     String departmentName, String departmentCode,
                     String managerName, String managerEmail, String phone,
                     String employeeName, int employeeId, String designation, String contactNumber,
                     int totalDays, int presentDays, int leaveDays,
                     double housingAllowance, double transportAllowance) {
        super(id, createdDate, updatedDate, companyName, address, phoneNumber, email,
              departmentName, departmentCode,
              managerName, managerEmail, phone,
              employeeName, employeeId, designation, contactNumber,
              totalDays, presentDays, leaveDays);
        if (housingAllowance < 0 || transportAllowance < 0) {
            throw new IllegalArgumentException("Allowances must be >= 0");
        }
        this.housingAllowance = housingAllowance;
        this.transportAllowance = transportAllowance;
    }

    public double getHousingAllowance() {
        return housingAllowance;
    }

    public void setHousingAllowance(double housingAllowance) {
        if (housingAllowance < 0) {
            throw new IllegalArgumentException("housingAllowance must be >= 0");
        }
        this.housingAllowance = housingAllowance;
    }

    public double getTransportAllowance() {
        return transportAllowance;
    }

    public void setTransportAllowance(double transportAllowance) {
        if (transportAllowance < 0) {
            throw new IllegalArgumentException("transportAllowance must be >= 0");
        }
        this.transportAllowance = transportAllowance;
    }
}

// Deduction
class Deduction extends Allowance {
    private double taxDeduction;
    private double loanDeduction;

    public Deduction(int id, String createdDate, String updatedDate,
                     String companyName, String address, String phoneNumber, String email,
                     String departmentName, String departmentCode,
                     String managerName, String managerEmail, String phone,
                     String employeeName, int employeeId, String designation, String contactNumber,
                     int totalDays, int presentDays, int leaveDays,
                     double housingAllowance, double transportAllowance,
                     double taxDeduction, double loanDeduction) {
        super(id, createdDate, updatedDate, companyName, address, phoneNumber, email,
              departmentName, departmentCode,
              managerName, managerEmail, phone,
              employeeName, employeeId, designation, contactNumber,
              totalDays, presentDays, leaveDays,
              housingAllowance, transportAllowance);
        if (taxDeduction < 0 || loanDeduction < 0) {
            throw new IllegalArgumentException("Deductions must be >= 0");
        }
        this.taxDeduction = taxDeduction;
        this.loanDeduction = loanDeduction;
    }

    public double getTaxDeduction() {
        return taxDeduction;
    }

    public void setTaxDeduction(double taxDeduction) {
        if (taxDeduction < 0) {
            throw new IllegalArgumentException("taxDeduction must be >= 0");
        }
        this.taxDeduction = taxDeduction;
    }

    public double getLoanDeduction() {
        return loanDeduction;
    }

    public void setLoanDeduction(double loanDeduction) {
        if (loanDeduction < 0) {
            throw new IllegalArgumentException("loanDeduction must be >= 0");
        }
        this.loanDeduction = loanDeduction;
    }
}

// Salary
class Salary extends Deduction {
    private double basicSalary;
    private double grossSalary;
    private double netSalary;

    public Salary(int id, String createdDate, String updatedDate,
                  String companyName, String address, String phoneNumber, String email,
                  String departmentName, String departmentCode,
                  String managerName, String managerEmail, String phone,
                  String employeeName, int employeeId, String designation, String contactNumber,
                  int totalDays, int presentDays, int leaveDays,
                  double housingAllowance, double transportAllowance,
                  double taxDeduction, double loanDeduction,
                  double basicSalary) {
        super(id, createdDate, updatedDate, companyName, address, phoneNumber, email,
              departmentName, departmentCode,
              managerName, managerEmail, phone,
              employeeName, employeeId, designation, contactNumber,
              totalDays, presentDays, leaveDays,
              housingAllowance, transportAllowance,
              taxDeduction, loanDeduction);
        if (basicSalary <= 0) {
            throw new IllegalArgumentException("basicSalary must be > 0");
        }
        this.basicSalary = basicSalary;
        this.grossSalary = 0.0;
        this.netSalary = 0.0;
    }

    public double getBasicSalary() {
        return basicSalary;
    }

    public void setBasicSalary(double basicSalary) {
        if (basicSalary <= 0) {
            throw new IllegalArgumentException("basicSalary must be > 0");
        }
        this.basicSalary = basicSalary;
    }

    public double getGrossSalary() {
        return grossSalary;
    }

    public void setGrossSalary(double grossSalary) {
        if (grossSalary <= 0) {
            throw new IllegalArgumentException("grossSalary must be > 0");
        }
        this.grossSalary = grossSalary;
    }

    public double getNetSalary() {
        return netSalary;
    }

    public void setNetSalary(double netSalary) {
        if (netSalary <= 0) {
            throw new IllegalArgumentException("netSalary must be > 0");
        }
        this.netSalary = netSalary;
    }
}

// Final PayrollRecord
public final class PayrollRecord extends Salary {

    public PayrollRecord(int id, String createdDate, String updatedDate,
                         String companyName, String address, String phoneNumber, String email,
                         String departmentName, String departmentCode,
                         String managerName, String managerEmail, String phone,
                         String employeeName, int employeeId, String designation, String contactNumber,
                         int totalDays, int presentDays, int leaveDays,
                         double housingAllowance, double transportAllowance,
                         double taxDeduction, double loanDeduction,
                         double basicSalary) {
        super(id, createdDate, updatedDate, companyName, address, phoneNumber, email,
              departmentName, departmentCode,
              managerName, managerEmail, phone,
              employeeName, employeeId, designation, contactNumber,
              totalDays, presentDays, leaveDays,
              housingAllowance, transportAllowance,
              taxDeduction, loanDeduction,
              basicSalary);
    }

    // calculateNetSalary() = basicSalary + allowances  d deductions
    public double calculateNetSalary() {
        double allowances = getHousingAllowance() + getTransportAllowance();
        double deductions = getTaxDeduction() + getLoanDeduction();
        double gross = getBasicSalary() + allowances;
        double net = getBasicSalary() + allowances - deductions;
        setGrossSalary(gross);
        setNetSalary(net);
        return net;
    }
}
