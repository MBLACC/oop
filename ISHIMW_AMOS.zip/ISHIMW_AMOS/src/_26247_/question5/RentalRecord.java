package _26247_.question5;

// Entity
class Entity {
    private int id;
    private String createdDate;
    private String updatedDate;

    public Entity(int id, String createdDate, String updatedDate) {
        if (id <= 0) {
            throw new IllegalArgumentException("id must be > 0");
        }
        this.id = id;
        this.createdDate = createdDate;
        this.updatedDate = updatedDate;
    }

    protected boolean isNullOrEmpty(String value) {
        return value == null || value.trim().isEmpty();
    }

    protected void validatePhone10(String phone) {
        if (phone == null || !phone.matches("\\d{10}")) {
            throw new IllegalArgumentException("Phone must be exactly 10 digits");
        }
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("id must be > 0");
        }
        this.id = id;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(String updatedDate) {
        this.updatedDate = updatedDate;
    }
}

// Company
class Company extends Entity {
    private String companyName;
    private String address;
    private String phoneNumber;

    public Company(int id, String createdDate, String updatedDate,
                   String companyName, String address, String phoneNumber) {
        super(id, createdDate, updatedDate);
        if (isNullOrEmpty(companyName) || isNullOrEmpty(address)) {
            throw new IllegalArgumentException("companyName and address must not be empty");
        }
        validatePhone10(phoneNumber);
        this.companyName = companyName;
        this.address = address;
        this.phoneNumber = phoneNumber;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        if (isNullOrEmpty(companyName)) {
            throw new IllegalArgumentException("companyName must not be empty");
        }
        this.companyName = companyName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        if (isNullOrEmpty(address)) {
            throw new IllegalArgumentException("address must not be empty");
        }
        this.address = address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        validatePhone10(phoneNumber);
        this.phoneNumber = phoneNumber;
    }
}

// Branch
class Branch extends Company {
    private String branchName;
    private String locationCode;

    public Branch(int id, String createdDate, String updatedDate,
                  String companyName, String address, String phoneNumber,
                  String branchName, String locationCode) {
        super(id, createdDate, updatedDate, companyName, address, phoneNumber);
        if (isNullOrEmpty(branchName)) {
            throw new IllegalArgumentException("branchName must not be empty");
        }
        if (isNullOrEmpty(locationCode) || locationCode.length() < 3) {
            throw new IllegalArgumentException("locationCode must be at least 3 chars");
        }
        this.branchName = branchName;
        this.locationCode = locationCode;
    }

    public String getBranchName() {
        return branchName;
    }

    public void setBranchName(String branchName) {
        if (isNullOrEmpty(branchName)) {
            throw new IllegalArgumentException("branchName must not be empty");
        }
        this.branchName = branchName;
    }

    public String getLocationCode() {
        return locationCode;
    }

    public void setLocationCode(String locationCode) {
        if (isNullOrEmpty(locationCode) || locationCode.length() < 3) {
            throw new IllegalArgumentException("locationCode must be at least 3 chars");
        }
        this.locationCode = locationCode;
    }
}

// Vehicle
class Vehicle extends Branch {
    private String vehicleType;
    private String registrationNumber;
    private double dailyRate;

    public Vehicle(int id, String createdDate, String updatedDate,
                   String companyName, String address, String phoneNumber,
                   String branchName, String locationCode,
                   String vehicleType, String registrationNumber, double dailyRate) {
        super(id, createdDate, updatedDate, companyName, address, phoneNumber,
              branchName, locationCode);
        if (isNullOrEmpty(vehicleType) || isNullOrEmpty(registrationNumber)) {
            throw new IllegalArgumentException("vehicleType and registrationNumber must not be empty");
        }
        if (dailyRate <= 0) {
            throw new IllegalArgumentException("dailyRate must be > 0");
        }
        this.vehicleType = vehicleType;
        this.registrationNumber = registrationNumber;
        this.dailyRate = dailyRate;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        if (isNullOrEmpty(vehicleType)) {
            throw new IllegalArgumentException("vehicleType must not be empty");
        }
        this.vehicleType = vehicleType;
    }

    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public void setRegistrationNumber(String registrationNumber) {
        if (isNullOrEmpty(registrationNumber)) {
            throw new IllegalArgumentException("registrationNumber must not be empty");
        }
        this.registrationNumber = registrationNumber;
    }

    public double getDailyRate() {
        return dailyRate;
    }

    public void setDailyRate(double dailyRate) {
        if (dailyRate <= 0) {
            throw new IllegalArgumentException("dailyRate must be > 0");
        }
        this.dailyRate = dailyRate;
    }
}

// Customer
class Customer extends Vehicle {
    private String customerName;
    private String licenseNumber;
    private String contactNumber;

    public Customer(int id, String createdDate, String updatedDate,
                    String companyName, String address, String phoneNumber,
                    String branchName, String locationCode,
                    String vehicleType, String registrationNumber, double dailyRate,
                    String customerName, String licenseNumber, String contactNumber) {
        super(id, createdDate, updatedDate, companyName, address, phoneNumber,
              branchName, locationCode,
              vehicleType, registrationNumber, dailyRate);
        if (isNullOrEmpty(customerName) || isNullOrEmpty(licenseNumber)) {
            throw new IllegalArgumentException("customerName and licenseNumber must not be empty");
        }
        validatePhone10(contactNumber);
        this.customerName = customerName;
        this.licenseNumber = licenseNumber;
        this.contactNumber = contactNumber;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        if (isNullOrEmpty(customerName)) {
            throw new IllegalArgumentException("customerName must not be empty");
        }
        this.customerName = customerName;
    }

    public String getLicenseNumber() {
        return licenseNumber;
    }

    public void setLicenseNumber(String licenseNumber) {
        if (isNullOrEmpty(licenseNumber)) {
            throw new IllegalArgumentException("licenseNumber must not be empty");
        }
        this.licenseNumber = licenseNumber;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        validatePhone10(contactNumber);
        this.contactNumber = contactNumber;
    }
}

// Rental
class Rental extends Customer {
    private String rentalDate;
    private String returnDate;
    private int rentalDays;

    public Rental(int id, String createdDate, String updatedDate,
                  String companyName, String address, String phoneNumber,
                  String branchName, String locationCode,
                  String vehicleType, String registrationNumber, double dailyRate,
                  String customerName, String licenseNumber, String contactNumber,
                  String rentalDate, String returnDate, int rentalDays) {
        super(id, createdDate, updatedDate, companyName, address, phoneNumber,
              branchName, locationCode,
              vehicleType, registrationNumber, dailyRate,
              customerName, licenseNumber, contactNumber);
        if (isNullOrEmpty(rentalDate) || isNullOrEmpty(returnDate)) {
            throw new IllegalArgumentException("rentalDate and returnDate must not be empty");
        }
        if (rentalDays <= 0) {
            throw new IllegalArgumentException("rentalDays must be > 0");
        }
        this.rentalDate = rentalDate;
        this.returnDate = returnDate;
        this.rentalDays = rentalDays;
    }

    public String getRentalDate() {
        return rentalDate;
    }

    public void setRentalDate(String rentalDate) {
        if (isNullOrEmpty(rentalDate)) {
            throw new IllegalArgumentException("rentalDate must not be empty");
        }
        this.rentalDate = rentalDate;
    }

    public String getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(String returnDate) {
        if (isNullOrEmpty(returnDate)) {
            throw new IllegalArgumentException("returnDate must not be empty");
        }
        this.returnDate = returnDate;
    }

    public int getRentalDays() {
        return rentalDays;
    }

    public void setRentalDays(int rentalDays) {
        if (rentalDays <= 0) {
            throw new IllegalArgumentException("rentalDays must be > 0");
        }
        this.rentalDays = rentalDays;
    }
}

// Charge
class Charge extends Rental {
    private double rentalCharge;
    private double penaltyCharge;

    public Charge(int id, String createdDate, String updatedDate,
                  String companyName, String address, String phoneNumber,
                  String branchName, String locationCode,
                  String vehicleType, String registrationNumber, double dailyRate,
                  String customerName, String licenseNumber, String contactNumber,
                  String rentalDate, String returnDate, int rentalDays,
                  double rentalCharge, double penaltyCharge) {
        super(id, createdDate, updatedDate, companyName, address, phoneNumber,
              branchName, locationCode,
              vehicleType, registrationNumber, dailyRate,
              customerName, licenseNumber, contactNumber,
              rentalDate, returnDate, rentalDays);
        if (rentalCharge < 0 || penaltyCharge < 0) {
            throw new IllegalArgumentException("Charges must be >= 0");
        }
        this.rentalCharge = rentalCharge;
        this.penaltyCharge = penaltyCharge;
    }

    public double getRentalCharge() {
        return rentalCharge;
    }

    public void setRentalCharge(double rentalCharge) {
        if (rentalCharge < 0) {
            throw new IllegalArgumentException("rentalCharge must be >= 0");
        }
        this.rentalCharge = rentalCharge;
    }

    public double getPenaltyCharge() {
        return penaltyCharge;
    }

    public void setPenaltyCharge(double penaltyCharge) {
        if (penaltyCharge < 0) {
            throw new IllegalArgumentException("penaltyCharge must be >= 0");
        }
        this.penaltyCharge = penaltyCharge;
    }
}

// Payment
class Payment extends Charge {
    private String paymentMode;
    private String transactionId;

    public Payment(int id, String createdDate, String updatedDate,
                   String companyName, String address, String phoneNumber,
                   String branchName, String locationCode,
                   String vehicleType, String registrationNumber, double dailyRate,
                   String customerName, String licenseNumber, String contactNumber,
                   String rentalDate, String returnDate, int rentalDays,
                   double rentalCharge, double penaltyCharge,
                   String paymentMode, String transactionId) {
        super(id, createdDate, updatedDate, companyName, address, phoneNumber,
              branchName, locationCode,
              vehicleType, registrationNumber, dailyRate,
              customerName, licenseNumber, contactNumber,
              rentalDate, returnDate, rentalDays,
              rentalCharge, penaltyCharge);
        if (isNullOrEmpty(paymentMode) || isNullOrEmpty(transactionId)) {
            throw new IllegalArgumentException("paymentMode and transactionId must not be empty");
        }
        this.paymentMode = paymentMode;
        this.transactionId = transactionId;
    }

    public String getPaymentMode() {
        return paymentMode;
    }

    public void setPaymentMode(String paymentMode) {
        if (isNullOrEmpty(paymentMode)) {
            throw new IllegalArgumentException("paymentMode must not be empty");
        }
        this.paymentMode = paymentMode;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        if (isNullOrEmpty(transactionId)) {
            throw new IllegalArgumentException("transactionId must not be empty");
        }
        this.transactionId = transactionId;
    }
}

// Invoice
class Invoice extends Payment {
    private double totalCharge;

    public Invoice(int id, String createdDate, String updatedDate,
                   String companyName, String address, String phoneNumber,
                   String branchName, String locationCode,
                   String vehicleType, String registrationNumber, double dailyRate,
                   String customerName, String licenseNumber, String contactNumber,
                   String rentalDate, String returnDate, int rentalDays,
                   double rentalCharge, double penaltyCharge,
                   String paymentMode, String transactionId,
                   double totalCharge) {
        super(id, createdDate, updatedDate, companyName, address, phoneNumber,
              branchName, locationCode,
              vehicleType, registrationNumber, dailyRate,
              customerName, licenseNumber, contactNumber,
              rentalDate, returnDate, rentalDays,
              rentalCharge, penaltyCharge,
              paymentMode, transactionId);
        if (totalCharge <= 0) {
            throw new IllegalArgumentException("totalCharge must be > 0");
        }
        this.totalCharge = totalCharge;
    }

    public double getTotalCharge() {
        return totalCharge;
    }

    public void setTotalCharge(double totalCharge) {
        if (totalCharge <= 0) {
            throw new IllegalArgumentException("totalCharge must be > 0");
        }
        this.totalCharge = totalCharge;
    }
}

// Final RentalRecord
public final class RentalRecord extends Invoice {

    public RentalRecord(int id, String createdDate, String updatedDate,
                        String companyName, String address, String phoneNumber,
                        String branchName, String locationCode,
                        String vehicleType, String registrationNumber, double dailyRate,
                        String customerName, String licenseNumber, String contactNumber,
                        String rentalDate, String returnDate, int rentalDays,
                        double rentalCharge, double penaltyCharge,
                        String paymentMode, String transactionId,
                        double totalCharge) {
        super(id, createdDate, updatedDate, companyName, address, phoneNumber,
              branchName, locationCode,
              vehicleType, registrationNumber, dailyRate,
              customerName, licenseNumber, contactNumber,
              rentalDate, returnDate, rentalDays,
              rentalCharge, penaltyCharge,
              paymentMode, transactionId,
              totalCharge);
    }

    // calculateTotalCharge() = rentalCharge + penaltyCharge
    public double calculateTotalCharge() {
        double calculated = getRentalCharge() + getPenaltyCharge();
        setTotalCharge(calculated);
        return calculated;
    }
}
