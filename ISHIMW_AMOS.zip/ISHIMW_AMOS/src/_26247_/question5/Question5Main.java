package _26247_.question5;

import java.util.Scanner;

public class Question5Main {

    private static final String STUDENT_ID = "26247";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int maxAttempts = 3;

        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            try {
                runProgram(scanner);
                break;
            } catch (Exception ex) {
                printlnWithId("ERROR: " + ex.getMessage());
                if (attempt == maxAttempts) {
                    printlnWithId("Maximum attempts (" + maxAttempts + ") reached. Exiting program.");
                } else {
                    printlnWithId("Please re-enter all details carefully. Attempt "
                            + (attempt + 1) + " of " + maxAttempts + ".");
                }
            }
        }

        scanner.close();
    }

    private static void runProgram(Scanner scanner) {
        printlnWithId("=== Question 5: Vehicle Rental System ===");

        int entityId = readPositiveInt(scanner, "Enter Entity ID (integer > 0): ");
        String createdDate = readNonEmptyString(scanner, "Enter Created Date (e.g., 2025-11-22): ");
        String updatedDate = readNonEmptyString(scanner, "Enter Updated Date (e.g., 2025-11-22): ");

        String companyName = readNonEmptyString(scanner, "Enter Company Name (non-empty text): ");
        String companyAddress = readNonEmptyString(scanner, "Enter Company Address (non-empty text): ");
        String companyPhone = readPhone10(scanner, "Enter Company Phone Number (exactly 10 digits): ");

        String branchName = readNonEmptyString(scanner, "Enter Branch Name (non-empty text): ");
        String locationCode = readNonEmptyString(scanner,
                "Enter Branch Location Code (at least 3 characters): ");

        String vehicleType = readNonEmptyString(scanner, "Enter Vehicle Type (non-empty text): ");
        String registrationNumber = readNonEmptyString(scanner,
                "Enter Registration Number (non-empty text): ");
        double dailyRate = readPositiveDouble(scanner,
                "Enter Daily Rate (number > 0): ");

        String customerName = readNonEmptyString(scanner, "Enter Customer Name (non-empty text): ");
        String licenseNumber = readNonEmptyString(scanner, "Enter License Number (non-empty text): ");
        String customerContact = readPhone10(scanner,
                "Enter Customer Contact Number (exactly 10 digits): ");

        String rentalDate = readNonEmptyString(scanner, "Enter Rental Date (e.g., 2025-11-22): ");
        String returnDate = readNonEmptyString(scanner, "Enter Return Date (e.g., 2025-11-25): ");
        int rentalDays = readPositiveInt(scanner, "Enter Rental Days (integer > 0): ");

        double rentalCharge = readNonNegativeDouble(scanner,
                "Enter Rental Charge (number >= 0): ");
        double penaltyCharge = readNonNegativeDouble(scanner,
                "Enter Penalty Charge (number >= 0): ");

        String paymentMode = readNonEmptyString(scanner, "Enter Payment Mode (e.g., Cash/Card): ");
        String transactionId = readNonEmptyString(scanner, "Enter Transaction ID (non-empty text): ");

        double totalChargeInput = readPositiveDouble(scanner,
                "Enter Total Charge (number > 0): ");

        RentalRecord record = new RentalRecord(
                entityId, createdDate, updatedDate,
                companyName, companyAddress, companyPhone,
                branchName, locationCode,
                vehicleType, registrationNumber, dailyRate,
                customerName, licenseNumber, customerContact,
                rentalDate, returnDate, rentalDays,
                rentalCharge, penaltyCharge,
                paymentMode, transactionId,
                totalChargeInput
        );

        double calculatedTotalCharge = record.calculateTotalCharge();

        printlnWithId("=== Rental Record Summary ===");
        printlnWithId("Entity ID: " + record.getId());
        printlnWithId("Company: " + record.getCompanyName() + ", " + record.getAddress());
        printlnWithId("Branch: " + record.getBranchName() + " (" + record.getLocationCode() + ")");
        printlnWithId("Vehicle: " + record.getVehicleType() + " - Reg: " + record.getRegistrationNumber());
        printlnWithId("Customer: " + record.getCustomerName() + " (License: " + record.getLicenseNumber() + ")");
        printlnWithId("Rental: " + record.getRentalDate() + " to " + record.getReturnDate()
                + " (" + record.getRentalDays() + " days)");
        printlnWithId("Rental Charge: " + record.getRentalCharge());
        printlnWithId("Penalty Charge: " + record.getPenaltyCharge());
        printlnWithId("Total Charge (calculated): " + calculatedTotalCharge);
        printlnWithId("Total Charge (stored): " + record.getTotalCharge());
    }

    private static void printlnWithId(String msg) {
        System.out.println(msg + " [" + STUDENT_ID + "]");
    }

    private static void printWithId(String msg) {
        System.out.print(msg + " [" + STUDENT_ID + "] ");
    }

    private static int readPositiveInt(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            if (!scanner.hasNextInt()) {
                scanner.nextLine();
                printlnWithId("Invalid input: please enter a whole number > 0. Attempts left: " + (3 - attempt));
                continue;
            }
            int value = scanner.nextInt();
            scanner.nextLine();
            if (value > 0) {
                return value;
            }
            printlnWithId("Value must be > 0. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return 0;
    }

    private static double readPositiveDouble(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            if (!scanner.hasNextDouble()) {
                scanner.nextLine();
                printlnWithId("Invalid input: please enter a number > 0. Attempts left: " + (3 - attempt));
                continue;
            }
            double value = scanner.nextDouble();
            scanner.nextLine();
            if (value > 0) {
                return value;
            }
            printlnWithId("Value must be > 0. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return 0.0;
    }

    private static double readNonNegativeDouble(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            if (!scanner.hasNextDouble()) {
                scanner.nextLine();
                printlnWithId("Invalid input: please enter a number >= 0. Attempts left: " + (3 - attempt));
                continue;
            }
            double value = scanner.nextDouble();
            scanner.nextLine();
            if (value >= 0) {
                return value;
            }
            printlnWithId("Value must be >= 0. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return 0.0;
    }

    private static String readNonEmptyString(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            String value = scanner.nextLine();
            if (value != null && !value.trim().isEmpty()) {
                return value.trim();
            }
            printlnWithId("Input must not be empty. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return null;
    }

    private static String readPhone10(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            String value = scanner.nextLine().trim();
            if (value.matches("\\d{10}")) {
                return value;
            }
            printlnWithId("Phone number must be exactly 10 digits (0-9). Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return null;
    }
}
