package _26247_.question9;

// Entity
class Entity {
    private int id;
    private String createdDate;
    private String updatedDate;

    public Entity(int id, String createdDate, String updatedDate) {
        if (id <= 0) {
            throw new IllegalArgumentException("id must be > 0");
        }
        this.id = id;
        this.createdDate = createdDate;
        this.updatedDate = updatedDate;
    }

    protected boolean isNullOrEmpty(String value) {
        return value == null || value.trim().isEmpty();
    }

    protected void validateEmail(String email) {
        if (isNullOrEmpty(email) || !email.contains("@")) {
            throw new IllegalArgumentException("Invalid email format");
        }
    }

    public int getId() { return id; }
    public void setId(int id) { if (id <= 0) throw new IllegalArgumentException("id must be > 0"); this.id = id; }

    public String getCreatedDate() { return createdDate; }
    public void setCreatedDate(String createdDate) { this.createdDate = createdDate; }

    public String getUpdatedDate() { return updatedDate; }
    public void setUpdatedDate(String updatedDate) { this.updatedDate = updatedDate; }
}

// Airline
class Airline extends Entity {
    private String airlineName;
    private String address;
    private String contactEmail;

    public Airline(int id, String createdDate, String updatedDate,
                   String airlineName, String address, String contactEmail) {
        super(id, createdDate, updatedDate);
        if (isNullOrEmpty(airlineName) || isNullOrEmpty(address)) {
            throw new IllegalArgumentException("airlineName and address must not be empty");
        }
        validateEmail(contactEmail);
        this.airlineName = airlineName;
        this.address = address;
        this.contactEmail = contactEmail;
    }

    public String getAirlineName() { return airlineName; }
    public void setAirlineName(String airlineName) {
        if (isNullOrEmpty(airlineName)) throw new IllegalArgumentException("airlineName must not be empty");
        this.airlineName = airlineName;
    }

    public String getAddress() { return address; }
    public void setAddress(String address) {
        if (isNullOrEmpty(address)) throw new IllegalArgumentException("address must not be empty");
        this.address = address;
    }

    public String getContactEmail() { return contactEmail; }
    public void setContactEmail(String contactEmail) { validateEmail(contactEmail); this.contactEmail = contactEmail; }
}

// Flight
class Flight extends Airline {
    private String flightNumber;
    private String destination;
    private String departureTime;

    public Flight(int id, String createdDate, String updatedDate,
                  String airlineName, String address, String contactEmail,
                  String flightNumber, String destination, String departureTime) {
        super(id, createdDate, updatedDate, airlineName, address, contactEmail);
        if (isNullOrEmpty(flightNumber) || isNullOrEmpty(destination) || isNullOrEmpty(departureTime)) {
            throw new IllegalArgumentException("Flight details must not be empty");
        }
        this.flightNumber = flightNumber;
        this.destination = destination;
        this.departureTime = departureTime;
    }

    public String getFlightNumber() { return flightNumber; }
    public void setFlightNumber(String flightNumber) {
        if (isNullOrEmpty(flightNumber)) throw new IllegalArgumentException("flightNumber must not be empty");
        this.flightNumber = flightNumber;
    }

    public String getDestination() { return destination; }
    public void setDestination(String destination) {
        if (isNullOrEmpty(destination)) throw new IllegalArgumentException("destination must not be empty");
        this.destination = destination;
    }

    public String getDepartureTime() { return departureTime; }
    public void setDepartureTime(String departureTime) {
        if (isNullOrEmpty(departureTime)) throw new IllegalArgumentException("departureTime must not be empty");
        this.departureTime = departureTime;
    }
}

// Passenger
class Passenger extends Flight {
    private String passengerName;
    private String passportNumber;
    private String nationality;

    public Passenger(int id, String createdDate, String updatedDate,
                     String airlineName, String address, String contactEmail,
                     String flightNumber, String destination, String departureTime,
                     String passengerName, String passportNumber, String nationality) {
        super(id, createdDate, updatedDate, airlineName, address, contactEmail,
              flightNumber, destination, departureTime);
        if (isNullOrEmpty(passengerName) || isNullOrEmpty(passportNumber) || isNullOrEmpty(nationality)) {
            throw new IllegalArgumentException("Passenger details must not be empty");
        }
        this.passengerName = passengerName;
        this.passportNumber = passportNumber;
        this.nationality = nationality;
    }

    public String getPassengerName() { return passengerName; }
    public void setPassengerName(String passengerName) {
        if (isNullOrEmpty(passengerName)) throw new IllegalArgumentException("passengerName must not be empty");
        this.passengerName = passengerName;
    }

    public String getPassportNumber() { return passportNumber; }
    public void setPassportNumber(String passportNumber) {
        if (isNullOrEmpty(passportNumber)) throw new IllegalArgumentException("passportNumber must not be empty");
        this.passportNumber = passportNumber;
    }

    public String getNationality() { return nationality; }
    public void setNationality(String nationality) {
        if (isNullOrEmpty(nationality)) throw new IllegalArgumentException("nationality must not be empty");
        this.nationality = nationality;
    }
}

// Seat
class Seat extends Passenger {
    private String seatNumber;
    private String seatType; // Economy/Business

    public Seat(int id, String createdDate, String updatedDate,
                String airlineName, String address, String contactEmail,
                String flightNumber, String destination, String departureTime,
                String passengerName, String passportNumber, String nationality,
                String seatNumber, String seatType) {
        super(id, createdDate, updatedDate, airlineName, address, contactEmail,
              flightNumber, destination, departureTime,
              passengerName, passportNumber, nationality);
        if (isNullOrEmpty(seatNumber)) {
            throw new IllegalArgumentException("seatNumber must not be empty");
        }
        if (!"Economy".equalsIgnoreCase(seatType) && !"Business".equalsIgnoreCase(seatType)) {
            throw new IllegalArgumentException("seatType must be Economy/Business");
        }
        this.seatNumber = seatNumber;
        this.seatType = seatType;
    }

    public String getSeatNumber() { return seatNumber; }
    public void setSeatNumber(String seatNumber) {
        if (isNullOrEmpty(seatNumber)) throw new IllegalArgumentException("seatNumber must not be empty");
        this.seatNumber = seatNumber;
    }

    public String getSeatType() { return seatType; }
    public void setSeatType(String seatType) {
        if (!"Economy".equalsIgnoreCase(seatType) && !"Business".equalsIgnoreCase(seatType)) {
            throw new IllegalArgumentException("seatType must be Economy/Business");
        }
        this.seatType = seatType;
    }
}

// Ticket
class Ticket extends Seat {
    private String ticketNumber;
    private double price;

    public Ticket(int id, String createdDate, String updatedDate,
                  String airlineName, String address, String contactEmail,
                  String flightNumber, String destination, String departureTime,
                  String passengerName, String passportNumber, String nationality,
                  String seatNumber, String seatType,
                  String ticketNumber, double price) {
        super(id, createdDate, updatedDate, airlineName, address, contactEmail,
              flightNumber, destination, departureTime,
              passengerName, passportNumber, nationality,
              seatNumber, seatType);
        if (isNullOrEmpty(ticketNumber)) {
            throw new IllegalArgumentException("ticketNumber must not be empty");
        }
        if (price <= 0) {
            throw new IllegalArgumentException("price must be > 0");
        }
        this.ticketNumber = ticketNumber;
        this.price = price;
    }

    public String getTicketNumber() { return ticketNumber; }
    public void setTicketNumber(String ticketNumber) {
        if (isNullOrEmpty(ticketNumber)) throw new IllegalArgumentException("ticketNumber must not be empty");
        this.ticketNumber = ticketNumber;
    }

    public double getPrice() { return price; }
    public void setPrice(double price) {
        if (price <= 0) throw new IllegalArgumentException("price must be > 0");
        this.price = price;
    }
}

// Baggage
class Baggage extends Ticket {
    private double baggageWeight;
    private double baggageFee;

    public Baggage(int id, String createdDate, String updatedDate,
                   String airlineName, String address, String contactEmail,
                   String flightNumber, String destination, String departureTime,
                   String passengerName, String passportNumber, String nationality,
                   String seatNumber, String seatType,
                   String ticketNumber, double price,
                   double baggageWeight, double baggageFee) {
        super(id, createdDate, updatedDate, airlineName, address, contactEmail,
              flightNumber, destination, departureTime,
              passengerName, passportNumber, nationality,
              seatNumber, seatType,
              ticketNumber, price);
        if (baggageWeight < 0 || baggageFee < 0) {
            throw new IllegalArgumentException("baggageWeight and baggageFee must be >= 0");
        }
        this.baggageWeight = baggageWeight;
        this.baggageFee = baggageFee;
    }

    public double getBaggageWeight() { return baggageWeight; }
    public void setBaggageWeight(double baggageWeight) {
        if (baggageWeight < 0) throw new IllegalArgumentException("baggageWeight must be >= 0");
        this.baggageWeight = baggageWeight;
    }

    public double getBaggageFee() { return baggageFee; }
    public void setBaggageFee(double baggageFee) {
        if (baggageFee < 0) throw new IllegalArgumentException("baggageFee must be >= 0");
        this.baggageFee = baggageFee;
    }
}

// Payment
class Payment extends Baggage {
    private String paymentDate;
    private String paymentMode;

    public Payment(int id, String createdDate, String updatedDate,
                   String airlineName, String address, String contactEmail,
                   String flightNumber, String destination, String departureTime,
                   String passengerName, String passportNumber, String nationality,
                   String seatNumber, String seatType,
                   String ticketNumber, double price,
                   double baggageWeight, double baggageFee,
                   String paymentDate, String paymentMode) {
        super(id, createdDate, updatedDate, airlineName, address, contactEmail,
              flightNumber, destination, departureTime,
              passengerName, passportNumber, nationality,
              seatNumber, seatType,
              ticketNumber, price,
              baggageWeight, baggageFee);
        if (isNullOrEmpty(paymentDate) || isNullOrEmpty(paymentMode)) {
            throw new IllegalArgumentException("paymentDate and paymentMode must not be empty");
        }
        this.paymentDate = paymentDate;
        this.paymentMode = paymentMode;
    }

    public String getPaymentDate() { return paymentDate; }
    public void setPaymentDate(String paymentDate) {
        if (isNullOrEmpty(paymentDate)) throw new IllegalArgumentException("paymentDate must not be empty");
        this.paymentDate = paymentDate;
    }

    public String getPaymentMode() { return paymentMode; }
    public void setPaymentMode(String paymentMode) {
        if (isNullOrEmpty(paymentMode)) throw new IllegalArgumentException("paymentMode must not be empty");
        this.paymentMode = paymentMode;
    }
}

// Invoice
class Invoice extends Payment {
    private double totalFare;

    public Invoice(int id, String createdDate, String updatedDate,
                   String airlineName, String address, String contactEmail,
                   String flightNumber, String destination, String departureTime,
                   String passengerName, String passportNumber, String nationality,
                   String seatNumber, String seatType,
                   String ticketNumber, double price,
                   double baggageWeight, double baggageFee,
                   String paymentDate, String paymentMode,
                   double totalFare) {
        super(id, createdDate, updatedDate, airlineName, address, contactEmail,
              flightNumber, destination, departureTime,
              passengerName, passportNumber, nationality,
              seatNumber, seatType,
              ticketNumber, price,
              baggageWeight, baggageFee,
              paymentDate, paymentMode);
        if (totalFare <= 0) {
            throw new IllegalArgumentException("totalFare must be > 0");
        }
        this.totalFare = totalFare;
    }

    public double getTotalFare() { return totalFare; }
    public void setTotalFare(double totalFare) {
        if (totalFare <= 0) throw new IllegalArgumentException("totalFare must be > 0");
        this.totalFare = totalFare;
    }
}

// Final TicketRecord
public final class TicketRecord extends Invoice {

    public TicketRecord(int id, String createdDate, String updatedDate,
                        String airlineName, String address, String contactEmail,
                        String flightNumber, String destination, String departureTime,
                        String passengerName, String passportNumber, String nationality,
                        String seatNumber, String seatType,
                        String ticketNumber, double price,
                        double baggageWeight, double baggageFee,
                        String paymentDate, String paymentMode,
                        double totalFare) {
        super(id, createdDate, updatedDate, airlineName, address, contactEmail,
              flightNumber, destination, departureTime,
              passengerName, passportNumber, nationality,
              seatNumber, seatType,
              ticketNumber, price,
              baggageWeight, baggageFee,
              paymentDate, paymentMode,
              totalFare);
    }

    // generateInvoice() = price + baggageFee
    public double generateInvoice() {
        double invoice = getPrice() + getBaggageFee();
        setTotalFare(invoice);
        return invoice;
    }
}
