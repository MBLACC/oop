package _26247_.question9;

import java.util.Scanner;

public class Question9Main {

    private static final String STUDENT_ID = "26247";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int maxAttempts = 3;

        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            try {
                runProgram(scanner);
                break;
            } catch (Exception ex) {
                printlnWithId("ERROR: " + ex.getMessage());
                if (attempt == maxAttempts) {
                    printlnWithId("Maximum attempts (" + maxAttempts + ") reached. Exiting program.");
                } else {
                    printlnWithId("Please re-enter all details carefully. Attempt "
                            + (attempt + 1) + " of " + maxAttempts + ".");
                }
            }
        }

        scanner.close();
    }

    private static void runProgram(Scanner scanner) {
        printlnWithId("=== Question 9: Airline Ticketing System ===");

        int entityId = readPositiveInt(scanner, "Enter Entity ID (integer > 0): ");
        String createdDate = readNonEmptyString(scanner, "Enter Created Date (e.g., 2025-11-22): ");
        String updatedDate = readNonEmptyString(scanner, "Enter Updated Date (e.g., 2025-11-22): ");

        String airlineName = readNonEmptyString(scanner, "Enter Airline Name (non-empty text): ");
        String airlineAddress = readNonEmptyString(scanner, "Enter Airline Address (non-empty text): ");
        String contactEmail = readEmail(scanner, "Enter Airline Contact Email (must contain @): ");

        String flightNumber = readNonEmptyString(scanner,
                "Enter Flight Number (non-empty text): ");
        String destination = readNonEmptyString(scanner,
                "Enter Destination (non-empty text): ");
        String departureTime = readNonEmptyString(scanner,
                "Enter Departure Time (e.g., 10:30): ");

        String passengerName = readNonEmptyString(scanner,
                "Enter Passenger Name (non-empty text): ");
        String passportNumber = readNonEmptyString(scanner,
                "Enter Passport Number (non-empty text): ");
        String nationality = readNonEmptyString(scanner,
                "Enter Nationality (non-empty text): ");

        String seatNumber = readNonEmptyString(scanner,
                "Enter Seat Number (non-empty text): ");
        String seatType = readChoice(scanner,
                "Enter Seat Type (Economy/Business): ",
                new String[]{"Economy", "Business"});

        String ticketNumber = readNonEmptyString(scanner,
                "Enter Ticket Number (non-empty text): ");
        double price = readPositiveDouble(scanner,
                "Enter Ticket Price (number > 0): ");

        double baggageWeight = readNonNegativeDouble(scanner,
                "Enter Baggage Weight (number >= 0): ");
        double baggageFee = readNonNegativeDouble(scanner,
                "Enter Baggage Fee (number >= 0): ");

        String paymentDate = readNonEmptyString(scanner,
                "Enter Payment Date (e.g., 2025-11-22): ");
        String paymentMode = readNonEmptyString(scanner,
                "Enter Payment Mode (e.g., Card/Cash): ");

        double totalFareInput = readPositiveDouble(scanner,
                "Enter Total Fare (number > 0): ");

        TicketRecord record = new TicketRecord(
                entityId, createdDate, updatedDate,
                airlineName, airlineAddress, contactEmail,
                flightNumber, destination, departureTime,
                passengerName, passportNumber, nationality,
                seatNumber, seatType,
                ticketNumber, price,
                baggageWeight, baggageFee,
                paymentDate, paymentMode,
                totalFareInput
        );

        double calculatedInvoice = record.generateInvoice();

        printlnWithId("=== Ticket Record Summary ===");
        printlnWithId("Entity ID: " + record.getId());
        printlnWithId("Airline: " + record.getAirlineName());
        printlnWithId("Flight: " + record.getFlightNumber() + " to " + record.getDestination()
                + " at " + record.getDepartureTime());
        printlnWithId("Passenger: " + record.getPassengerName() + " (" + record.getPassportNumber()
                + ", " + record.getNationality() + ")");
        printlnWithId("Seat: " + record.getSeatNumber() + " (" + record.getSeatType() + ")");
        printlnWithId("Ticket Price: " + record.getPrice());
        printlnWithId("Baggage Fee: " + record.getBaggageFee());
        printlnWithId("Total Fare (calculated): " + calculatedInvoice);
    }

    private static void printlnWithId(String msg) {
        System.out.println(msg + " [" + STUDENT_ID + "]");
    }

    private static void printWithId(String msg) {
        System.out.print(msg + " [" + STUDENT_ID + "] ");
    }

    private static int readPositiveInt(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            if (!scanner.hasNextInt()) {
                scanner.nextLine();
                printlnWithId("Invalid input: please enter a whole number > 0. Attempts left: " + (3 - attempt));
                continue;
            }
            int value = scanner.nextInt();
            scanner.nextLine();
            if (value > 0) {
                return value;
            }
            printlnWithId("Value must be > 0. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return 0;
    }

    private static double readPositiveDouble(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            if (!scanner.hasNextDouble()) {
                scanner.nextLine();
                printlnWithId("Invalid input: please enter a number > 0. Attempts left: " + (3 - attempt));
                continue;
            }
            double value = scanner.nextDouble();
            scanner.nextLine();
            if (value > 0) {
                return value;
            }
            printlnWithId("Value must be > 0. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return 0.0;
    }

    private static double readNonNegativeDouble(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            if (!scanner.hasNextDouble()) {
                scanner.nextLine();
                printlnWithId("Invalid input: please enter a number >= 0. Attempts left: " + (3 - attempt));
                continue;
            }
            double value = scanner.nextDouble();
            scanner.nextLine();
            if (value >= 0) {
                return value;
            }
            printlnWithId("Value must be >= 0. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return 0.0;
    }

    private static String readNonEmptyString(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            String value = scanner.nextLine();
            if (value != null && !value.trim().isEmpty()) {
                return value.trim();
            }
            printlnWithId("Input must not be empty. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return null;
    }

    private static String readEmail(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            String value = scanner.nextLine().trim();
            if (!value.isEmpty() && value.contains("@")) {
                return value;
            }
            printlnWithId("Invalid email: must contain '@'. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return null;
    }

    private static String readChoice(Scanner scanner, String prompt, String[] allowed) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            String value = scanner.nextLine().trim();
            for (String option : allowed) {
                if (option.equalsIgnoreCase(value)) {
                    return option;
                }
            }
            StringBuilder sb = new StringBuilder("Invalid choice. Allowed values: ");
            for (int i = 0; i < allowed.length; i++) {
                sb.append(allowed[i]);
                if (i < allowed.length - 1) sb.append(", ");
            }
            sb.append(". Attempts left: ").append(3 - attempt);
            printlnWithId(sb.toString());
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return null;
    }
}
