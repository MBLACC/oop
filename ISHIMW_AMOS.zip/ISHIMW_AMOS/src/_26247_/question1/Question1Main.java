package _26247_.question1;

import java.util.Scanner;

public class Question1Main {

    private static final String STUDENT_ID = "26247";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int maxAttempts = 3;

        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            try {
                runProgram(scanner);
                break; // success
            } catch (HospitalDataException | IllegalArgumentException ex) {
                printlnWithId("ERROR: " + ex.getMessage());
                if (attempt == maxAttempts) {
                    printlnWithId("Maximum attempts (" + maxAttempts + ") reached. Exiting program.");
                } else {
                    printlnWithId("Please re-enter all details carefully. Attempt "
                            + (attempt + 1) + " of " + maxAttempts + ".");
                }
            }
        }

        scanner.close();
    }

    private static void runProgram(Scanner scanner) {
        printlnWithId("=== Question 1: Hospital Management System ===");

        int entityId = readPositiveInt(scanner, "Enter Entity ID (integer > 0): ");
        String createdDate = readNonEmptyString(scanner, "Enter Created Date (e.g., 2025-11-22): ");
        String updatedDate = readNonEmptyString(scanner, "Enter Updated Date (e.g., 2025-11-22): ");

        String hospitalName = readNonEmptyString(scanner, "Enter Hospital Name (non-empty text): ");
        String hospitalAddress = readNonEmptyString(scanner, "Enter Hospital Address (non-empty text): ");
        String hospitalPhone = readPhone10(scanner, "Enter Hospital Phone Number (exactly 10 digits): ");
        String hospitalEmail = readEmail(scanner, "Enter Hospital Email (must contain @): ");

        String departmentName = readNonEmptyString(scanner, "Enter Department Name (non-empty text): ");
        String departmentCode = readAlphaNumericMinLen(scanner,
                "Enter Department Code (alphanumeric, at least 3 characters): ", 3);

        String doctorName = readNonEmptyString(scanner, "Enter Doctor Name (non-empty text): ");
        String specialization = readNonEmptyString(scanner, "Enter Doctor Specialization (non-empty text): ");
        String doctorEmail = readEmail(scanner, "Enter Doctor Email (must contain @): ");
        String doctorPhone = readPhone10(scanner, "Enter Doctor Phone (exactly 10 digits): ");

        String nurseName = readNonEmptyString(scanner, "Enter Nurse Name (non-empty text): ");
        String nurseShift = readChoice(scanner,
                "Enter Nurse Shift (Day/Night): ", new String[]{"Day", "Night"});
        int yearsOfExperience = readNonNegativeInt(scanner,
                "Enter Nurse Years of Experience (integer >= 0): ");

        String patientName = readNonEmptyString(scanner, "Enter Patient Name (non-empty text): ");
        int patientAge = readPositiveInt(scanner, "Enter Patient Age (integer > 0): ");
        String patientGender = readChoice(scanner,
                "Enter Patient Gender (Male/Female/Other): ",
                new String[]{"Male", "Female", "Other"});
        String patientContact = readPhone10(scanner,
                "Enter Patient Contact Number (exactly 10 digits): ");

        String admissionDate = readNonEmptyString(scanner,
                "Enter Admission Date (e.g., 2025-11-22): ");
        String roomNumber = readNonEmptyString(scanner,
                "Enter Room Number (non-empty text): ");
        double roomCharges = readPositiveDouble(scanner,
                "Enter Room Charges (number > 0): ");

        String diagnosis = readNonEmptyString(scanner,
                "Enter Diagnosis (non-empty text): ");
        String treatmentGiven = readNonEmptyString(scanner,
                "Enter Treatment Given (non-empty text): ");
        double treatmentCost = readPositiveDouble(scanner,
                "Enter Treatment Cost (number > 0): ");

        double doctorFee = readPositiveDouble(scanner,
                "Enter Doctor Fee (number > 0): ");
        double medicineCost = readPositiveDouble(scanner,
                "Enter Medicine Cost (number > 0): ");

        HospitalRecord record = new HospitalRecord(
                entityId, createdDate, updatedDate,
                hospitalName, hospitalAddress, hospitalPhone, hospitalEmail,
                departmentName, departmentCode,
                doctorName, specialization, doctorEmail, doctorPhone,
                nurseName, nurseShift, yearsOfExperience,
                patientName, patientAge, patientGender, patientContact,
                admissionDate, roomNumber, roomCharges,
                diagnosis, treatmentGiven, treatmentCost,
                doctorFee, medicineCost
        );

        double finalBill = record.generateBill();

        printlnWithId("=== Hospital Record Summary ===");
        printlnWithId("Entity ID: " + record.getId());
        printlnWithId("Hospital: " + record.getHospitalName() + ", " + record.getAddress());
        printlnWithId("Department: " + record.getDepartmentName() + " (" + record.getDepartmentCode() + ")");
        printlnWithId("Doctor: " + record.getDoctorName() + " - " + record.getSpecialization());
        printlnWithId("Nurse: " + record.getNurseName() + " (" + record.getShift() + " shift, "
                + record.getYearsOfExperience() + " years exp)");
        printlnWithId("Patient: " + record.getPatientName() + ", Age: " + record.getAge()
                + ", Gender: " + record.getGender());
        printlnWithId("Admission: Date=" + record.getAdmissionDate() + ", Room=" + record.getRoomNumber());
        printlnWithId("Diagnosis: " + record.getDiagnosis());
        printlnWithId("Treatment: " + record.getTreatmentGiven());
        printlnWithId("Room Charges: " + record.getRoomCharges());
        printlnWithId("Treatment Cost: " + record.getTreatmentCost());
        printlnWithId("Doctor Fee: " + record.getDoctorFee());
        printlnWithId("Medicine Cost: " + record.getMedicineCost());
        printlnWithId("TOTAL BILL: " + finalBill);
    }

    private static void printlnWithId(String msg) {
        System.out.println(msg + " [" + STUDENT_ID + "]");
    }

    private static void printWithId(String msg) {
        System.out.print(msg + " [" + STUDENT_ID + "] ");
    }

    private static int readPositiveInt(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            if (!scanner.hasNextInt()) {
                scanner.nextLine();
                printlnWithId("Invalid input: please enter a whole number > 0. Attempts left: " + (3 - attempt));
                continue;
            }
            int value = scanner.nextInt();
            scanner.nextLine();
            if (value > 0) {
                return value;
            }
            printlnWithId("Value must be > 0. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return 0;
    }

    private static int readNonNegativeInt(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            if (!scanner.hasNextInt()) {
                scanner.nextLine();
                printlnWithId("Invalid input: please enter a whole number >= 0. Attempts left: " + (3 - attempt));
                continue;
            }
            int value = scanner.nextInt();
            scanner.nextLine();
            if (value >= 0) {
                return value;
            }
            printlnWithId("Value must be >= 0. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return 0;
    }

    private static double readPositiveDouble(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            if (!scanner.hasNextDouble()) {
                scanner.nextLine();
                printlnWithId("Invalid input: please enter a number > 0. Attempts left: " + (3 - attempt));
                continue;
            }
            double value = scanner.nextDouble();
            scanner.nextLine();
            if (value > 0) {
                return value;
            }
            printlnWithId("Value must be > 0. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return 0.0;
    }

    private static String readNonEmptyString(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            String value = scanner.nextLine();
            if (value != null && !value.trim().isEmpty()) {
                return value.trim();
            }
            printlnWithId("Input must not be empty. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return null;
    }

    private static String readPhone10(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            String value = scanner.nextLine().trim();
            if (value.matches("\\d{10}")) {
                return value;
            }
            printlnWithId("Phone number must be exactly 10 digits (0-9). Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return null;
    }

    private static String readEmail(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            String value = scanner.nextLine().trim();
            if (!value.isEmpty() && value.contains("@")) {
                return value;
            }
            printlnWithId("Invalid email: must contain '@'. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return null;
    }

    private static String readAlphaNumericMinLen(Scanner scanner, String prompt, int minLen) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            String value = scanner.nextLine().trim();
            if (value.length() >= minLen && value.matches("[a-zA-Z0-9]+")) {
                return value;
            }
            printlnWithId("Invalid code: must be alphanumeric and at least "
                    + minLen + " characters. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return null;
    }

    private static String readChoice(Scanner scanner, String prompt, String[] allowed) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            String value = scanner.nextLine().trim();
            for (String option : allowed) {
                if (option.equalsIgnoreCase(value)) {
                    return option; // normalize
                }
            }
            StringBuilder sb = new StringBuilder("Invalid choice. Allowed values: ");
            for (int i = 0; i < allowed.length; i++) {
                sb.append(allowed[i]);
                if (i < allowed.length - 1) sb.append(", ");
            }
            sb.append(". Attempts left: ").append(3 - attempt);
            printlnWithId(sb.toString());
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return null;
    }
}
