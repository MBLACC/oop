package _26247_.question1;

// Entity  common base class
class Entity {
    private int id;
    private String createdDate;
    private String updatedDate;

    public Entity(int id, String createdDate, String updatedDate) {
        if (id <= 0) {
            throw new HospitalDataException("id must be > 0");
        }
        if (isNullOrEmpty(createdDate) || isNullOrEmpty(updatedDate)) {
            throw new HospitalDataException("Dates must not be null or empty");
        }
        this.id = id;
        this.createdDate = createdDate;
        this.updatedDate = updatedDate;
    }

    protected boolean isNullOrEmpty(String value) {
        return value == null || value.trim().isEmpty();
    }

    protected void validatePhone10(String phone) {
        if (phone == null || !phone.matches("\\d{10}")) {
            throw new HospitalDataException("Phone must be exactly 10 digits");
        }
    }

    protected void validateEmail(String email) {
        if (isNullOrEmpty(email) || !email.contains("@")) {
            throw new HospitalDataException("Invalid email format");
        }
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        if (id <= 0) {
            throw new HospitalDataException("id must be > 0");
        }
        this.id = id;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        if (isNullOrEmpty(createdDate)) {
            throw new HospitalDataException("createdDate must not be empty");
        }
        this.createdDate = createdDate;
    }

    public String getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(String updatedDate) {
        if (isNullOrEmpty(updatedDate)) {
            throw new HospitalDataException("updatedDate must not be empty");
        }
        this.updatedDate = updatedDate;
    }
}

// Hospital
class Hospital extends Entity {
    private String hospitalName;
    private String address;
    private String phoneNumber;
    private String email;

    public Hospital(int id, String createdDate, String updatedDate,
                    String hospitalName, String address,
                    String phoneNumber, String email) {
        super(id, createdDate, updatedDate);
        if (isNullOrEmpty(hospitalName) || isNullOrEmpty(address)) {
            throw new HospitalDataException("Hospital name and address must not be empty");
        }
        validatePhone10(phoneNumber);
        validateEmail(email);
        this.hospitalName = hospitalName;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.email = email;
    }

    public String getHospitalName() {
        return hospitalName;
    }

    public void setHospitalName(String hospitalName) {
        if (isNullOrEmpty(hospitalName)) {
            throw new HospitalDataException("hospitalName must not be empty");
        }
        this.hospitalName = hospitalName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        if (isNullOrEmpty(address)) {
            throw new HospitalDataException("address must not be empty");
        }
        this.address = address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        validatePhone10(phoneNumber);
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        validateEmail(email);
        this.email = email;
    }
}

// Department
class Department extends Hospital {
    private String departmentName;
    private String departmentCode;

    public Department(int id, String createdDate, String updatedDate,
                      String hospitalName, String address, String phoneNumber, String email,
                      String departmentName, String departmentCode) {
        super(id, createdDate, updatedDate, hospitalName, address, phoneNumber, email);
        if (isNullOrEmpty(departmentName)) {
            throw new HospitalDataException("departmentName must not be empty");
        }
        if (isNullOrEmpty(departmentCode) || departmentCode.length() < 3 ||
                !departmentCode.matches("[a-zA-Z0-9]+")) {
            throw new HospitalDataException("departmentCode must be alphanumeric and at least 3 chars");
        }
        this.departmentName = departmentName;
        this.departmentCode = departmentCode;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        if (isNullOrEmpty(departmentName)) {
            throw new HospitalDataException("departmentName must not be empty");
        }
        this.departmentName = departmentName;
    }

    public String getDepartmentCode() {
        return departmentCode;
    }

    public void setDepartmentCode(String departmentCode) {
        if (isNullOrEmpty(departmentCode) || departmentCode.length() < 3 ||
                !departmentCode.matches("[a-zA-Z0-9]+")) {
            throw new HospitalDataException("departmentCode must be alphanumeric and at least 3 chars");
        }
        this.departmentCode = departmentCode;
    }
}

// Doctor
class Doctor extends Department {
    private String doctorName;
    private String specialization;
    private String doctorEmail;
    private String phone;

    public Doctor(int id, String createdDate, String updatedDate,
                  String hospitalName, String address, String phoneNumber, String email,
                  String departmentName, String departmentCode,
                  String doctorName, String specialization,
                  String doctorEmail, String phone) {
        super(id, createdDate, updatedDate, hospitalName, address, phoneNumber, email,
              departmentName, departmentCode);
        if (isNullOrEmpty(doctorName) || isNullOrEmpty(specialization)) {
            throw new HospitalDataException("Doctor name and specialization must not be empty");
        }
        validateEmail(doctorEmail);
        validatePhone10(phone);
        this.doctorName = doctorName;
        this.specialization = specialization;
        this.doctorEmail = doctorEmail;
        this.phone = phone;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public void setDoctorName(String doctorName) {
        if (isNullOrEmpty(doctorName)) {
            throw new HospitalDataException("doctorName must not be empty");
        }
        this.doctorName = doctorName;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        if (isNullOrEmpty(specialization)) {
            throw new HospitalDataException("specialization must not be empty");
        }
        this.specialization = specialization;
    }

    public String getDoctorEmail() {
        return doctorEmail;
    }

    public void setDoctorEmail(String doctorEmail) {
        validateEmail(doctorEmail);
        this.doctorEmail = doctorEmail;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        validatePhone10(phone);
        this.phone = phone;
    }
}

// Nurse
class Nurse extends Doctor {
    private String nurseName;
    private String shift; // Day/Night
    private int yearsOfExperience;

    public Nurse(int id, String createdDate, String updatedDate,
                 String hospitalName, String address, String phoneNumber, String email,
                 String departmentName, String departmentCode,
                 String doctorName, String specialization,
                 String doctorEmail, String phone,
                 String nurseName, String shift, int yearsOfExperience) {
        super(id, createdDate, updatedDate, hospitalName, address, phoneNumber, email,
              departmentName, departmentCode,
              doctorName, specialization, doctorEmail, phone);
        if (isNullOrEmpty(nurseName)) {
            throw new HospitalDataException("nurseName must not be empty");
        }
        if (!"Day".equalsIgnoreCase(shift) && !"Night".equalsIgnoreCase(shift)) {
            throw new HospitalDataException("shift must be 'Day' or 'Night'");
        }
        if (yearsOfExperience < 0) {
            throw new HospitalDataException("yearsOfExperience must be >= 0");
        }
        this.nurseName = nurseName;
        this.shift = shift;
        this.yearsOfExperience = yearsOfExperience;
    }

    public String getNurseName() {
        return nurseName;
    }

    public void setNurseName(String nurseName) {
        if (isNullOrEmpty(nurseName)) {
            throw new HospitalDataException("nurseName must not be empty");
        }
        this.nurseName = nurseName;
    }

    public String getShift() {
        return shift;
    }

    public void setShift(String shift) {
        if (!"Day".equalsIgnoreCase(shift) && !"Night".equalsIgnoreCase(shift)) {
            throw new HospitalDataException("shift must be 'Day' or 'Night'");
        }
        this.shift = shift;
    }

    public int getYearsOfExperience() {
        return yearsOfExperience;
    }

    public void setYearsOfExperience(int yearsOfExperience) {
        if (yearsOfExperience < 0) {
            throw new HospitalDataException("yearsOfExperience must be >= 0");
        }
        this.yearsOfExperience = yearsOfExperience;
    }
}

// Patient
class Patient extends Nurse {
    private String patientName;
    private int age;
    private String gender; // Male/Female/Other
    private String contactNumber;

    public Patient(int id, String createdDate, String updatedDate,
                   String hospitalName, String address, String phoneNumber, String email,
                   String departmentName, String departmentCode,
                   String doctorName, String specialization,
                   String doctorEmail, String phone,
                   String nurseName, String shift, int yearsOfExperience,
                   String patientName, int age, String gender, String contactNumber) {
        super(id, createdDate, updatedDate, hospitalName, address, phoneNumber, email,
              departmentName, departmentCode,
              doctorName, specialization, doctorEmail, phone,
              nurseName, shift, yearsOfExperience);
        if (isNullOrEmpty(patientName)) {
            throw new HospitalDataException("patientName must not be empty");
        }
        if (age <= 0) {
            throw new HospitalDataException("age must be > 0");
        }
        if (!"Male".equalsIgnoreCase(gender) &&
            !"Female".equalsIgnoreCase(gender) &&
            !"Other".equalsIgnoreCase(gender)) {
            throw new HospitalDataException("gender must be Male/Female/Other");
        }
        validatePhone10(contactNumber);
        this.patientName = patientName;
        this.age = age;
        this.gender = gender;
        this.contactNumber = contactNumber;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        if (isNullOrEmpty(patientName)) {
            throw new HospitalDataException("patientName must not be empty");
        }
        this.patientName = patientName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        if (age <= 0) {
            throw new HospitalDataException("age must be > 0");
        }
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        if (!"Male".equalsIgnoreCase(gender) &&
            !"Female".equalsIgnoreCase(gender) &&
            !"Other".equalsIgnoreCase(gender)) {
            throw new HospitalDataException("gender must be Male/Female/Other");
        }
        this.gender = gender;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        validatePhone10(contactNumber);
        this.contactNumber = contactNumber;
    }
}

// Admission
class Admission extends Patient {
    private String admissionDate;
    private String roomNumber;
    private double roomCharges;

    public Admission(int id, String createdDate, String updatedDate,
                     String hospitalName, String address, String phoneNumber, String email,
                     String departmentName, String departmentCode,
                     String doctorName, String specialization,
                     String doctorEmail, String phone,
                     String nurseName, String shift, int yearsOfExperience,
                     String patientName, int age, String gender, String contactNumber,
                     String admissionDate, String roomNumber, double roomCharges) {
        super(id, createdDate, updatedDate, hospitalName, address, phoneNumber, email,
              departmentName, departmentCode,
              doctorName, specialization, doctorEmail, phone,
              nurseName, shift, yearsOfExperience,
              patientName, age, gender, contactNumber);
        if (isNullOrEmpty(admissionDate) || isNullOrEmpty(roomNumber)) {
            throw new HospitalDataException("admissionDate and roomNumber must not be empty");
        }
        if (roomCharges <= 0) {
            throw new HospitalDataException("roomCharges must be > 0");
        }
        this.admissionDate = admissionDate;
        this.roomNumber = roomNumber;
        this.roomCharges = roomCharges;
    }

    public String getAdmissionDate() {
        return admissionDate;
    }

    public void setAdmissionDate(String admissionDate) {
        if (isNullOrEmpty(admissionDate)) {
            throw new HospitalDataException("admissionDate must not be empty");
        }
        this.admissionDate = admissionDate;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        if (isNullOrEmpty(roomNumber)) {
            throw new HospitalDataException("roomNumber must not be empty");
        }
        this.roomNumber = roomNumber;
    }

    public double getRoomCharges() {
        return roomCharges;
    }

    public void setRoomCharges(double roomCharges) {
        if (roomCharges <= 0) {
            throw new HospitalDataException("roomCharges must be > 0");
        }
        this.roomCharges = roomCharges;
    }
}

// Treatment
class Treatment extends Admission {
    private String diagnosis;
    private String treatmentGiven;
    private double treatmentCost;

    public Treatment(int id, String createdDate, String updatedDate,
                     String hospitalName, String address, String phoneNumber, String email,
                     String departmentName, String departmentCode,
                     String doctorName, String specialization,
                     String doctorEmail, String phone,
                     String nurseName, String shift, int yearsOfExperience,
                     String patientName, int age, String gender, String contactNumber,
                     String admissionDate, String roomNumber, double roomCharges,
                     String diagnosis, String treatmentGiven, double treatmentCost) {
        super(id, createdDate, updatedDate, hospitalName, address, phoneNumber, email,
              departmentName, departmentCode,
              doctorName, specialization, doctorEmail, phone,
              nurseName, shift, yearsOfExperience,
              patientName, age, gender, contactNumber,
              admissionDate, roomNumber, roomCharges);
        if (isNullOrEmpty(diagnosis) || isNullOrEmpty(treatmentGiven)) {
            throw new HospitalDataException("diagnosis and treatmentGiven must not be empty");
        }
        if (treatmentCost <= 0) {
            throw new HospitalDataException("treatmentCost must be > 0");
        }
        this.diagnosis = diagnosis;
        this.treatmentGiven = treatmentGiven;
        this.treatmentCost = treatmentCost;
    }

    public String getDiagnosis() {
        return diagnosis;
    }

    public void setDiagnosis(String diagnosis) {
        if (isNullOrEmpty(diagnosis)) {
            throw new HospitalDataException("diagnosis must not be empty");
        }
        this.diagnosis = diagnosis;
    }

    public String getTreatmentGiven() {
        return treatmentGiven;
    }

    public void setTreatmentGiven(String treatmentGiven) {
        if (isNullOrEmpty(treatmentGiven)) {
            throw new HospitalDataException("treatmentGiven must not be empty");
        }
        this.treatmentGiven = treatmentGiven;
    }

    public double getTreatmentCost() {
        return treatmentCost;
    }

    public void setTreatmentCost(double treatmentCost) {
        if (treatmentCost <= 0) {
            throw new HospitalDataException("treatmentCost must be > 0");
        }
        this.treatmentCost = treatmentCost;
    }
}

// Bill
class Bill extends Treatment {
    private double doctorFee;
    private double medicineCost;
    private double totalBill;

    public Bill(int id, String createdDate, String updatedDate,
                String hospitalName, String address, String phoneNumber, String email,
                String departmentName, String departmentCode,
                String doctorName, String specialization,
                String doctorEmail, String phone,
                String nurseName, String shift, int yearsOfExperience,
                String patientName, int age, String gender, String contactNumber,
                String admissionDate, String roomNumber, double roomCharges,
                String diagnosis, String treatmentGiven, double treatmentCost,
                double doctorFee, double medicineCost) {
        super(id, createdDate, updatedDate, hospitalName, address, phoneNumber, email,
              departmentName, departmentCode,
              doctorName, specialization, doctorEmail, phone,
              nurseName, shift, yearsOfExperience,
              patientName, age, gender, contactNumber,
              admissionDate, roomNumber, roomCharges,
              diagnosis, treatmentGiven, treatmentCost);
        if (doctorFee <= 0 || medicineCost <= 0) {
            throw new HospitalDataException("doctorFee and medicineCost must be > 0");
        }
        this.doctorFee = doctorFee;
        this.medicineCost = medicineCost;
        this.totalBill = 0.0; // will be computed in HospitalRecord.generateBill()
    }

    public double getDoctorFee() {
        return doctorFee;
    }

    public void setDoctorFee(double doctorFee) {
        if (doctorFee <= 0) {
            throw new HospitalDataException("doctorFee must be > 0");
        }
        this.doctorFee = doctorFee;
    }

    public double getMedicineCost() {
        return medicineCost;
    }

    public void setMedicineCost(double medicineCost) {
        if (medicineCost <= 0) {
            throw new HospitalDataException("medicineCost must be > 0");
        }
        this.medicineCost = medicineCost;
    }

    public double getTotalBill() {
        return totalBill;
    }

    public void setTotalBill(double totalBill) {
        if (totalBill <= 0) {
            throw new HospitalDataException("totalBill must be > 0");
        }
        this.totalBill = totalBill;
    }
}

// Final class HospitalRecord
public final class HospitalRecord extends Bill {

    public HospitalRecord(int id, String createdDate, String updatedDate,
                          String hospitalName, String address, String phoneNumber, String email,
                          String departmentName, String departmentCode,
                          String doctorName, String specialization,
                          String doctorEmail, String phone,
                          String nurseName, String shift, int yearsOfExperience,
                          String patientName, int age, String gender, String contactNumber,
                          String admissionDate, String roomNumber, double roomCharges,
                          String diagnosis, String treatmentGiven, double treatmentCost,
                          double doctorFee, double medicineCost) {
        super(id, createdDate, updatedDate, hospitalName, address, phoneNumber, email,
              departmentName, departmentCode,
              doctorName, specialization, doctorEmail, phone,
              nurseName, shift, yearsOfExperience,
              patientName, age, gender, contactNumber,
              admissionDate, roomNumber, roomCharges,
              diagnosis, treatmentGiven, treatmentCost,
              doctorFee, medicineCost);
    }

    // Method: generateBill() = roomCharges + treatmentCost + doctorFee + medicineCost
    public double generateBill() {
        double billAmount = getRoomCharges() + getTreatmentCost() + getDoctorFee() + getMedicineCost();
        setTotalBill(billAmount);
        return billAmount;
    }
}

// Custom exception for invalid hospital data
class HospitalDataException extends RuntimeException {
    public HospitalDataException(String message) {
        super(message);
    }
}
