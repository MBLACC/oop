package _26247_.question6;

import java.util.Scanner;

public class Question6Main {

    private static final String STUDENT_ID = "26247";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int maxAttempts = 3;

        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            try {
                runProgram(scanner);
                break;
            } catch (Exception ex) {
                printlnWithId("ERROR: " + ex.getMessage());
                if (attempt == maxAttempts) {
                    printlnWithId("Maximum attempts (" + maxAttempts + ") reached. Exiting program.");
                } else {
                    printlnWithId("Please re-enter all details carefully. Attempt "
                            + (attempt + 1) + " of " + maxAttempts + ".");
                }
            }
        }

        scanner.close();
    }

    private static void runProgram(Scanner scanner) {
        printlnWithId("=== Question 6: Banking System ===");

        int entityId = readPositiveInt(scanner, "Enter Entity ID (integer > 0): ");
        String createdDate = readNonEmptyString(scanner, "Enter Created Date (e.g., 2025-11-22): ");
        String updatedDate = readNonEmptyString(scanner, "Enter Updated Date (e.g., 2025-11-22): ");

        String bankName = readNonEmptyString(scanner, "Enter Bank Name (non-empty text): ");
        String branchCode = readNonEmptyString(scanner,
                "Enter Branch Code (at least 3 characters): ");
        String bankAddress = readNonEmptyString(scanner, "Enter Bank Address (non-empty text): ");

        String accountNumber = readNonEmptyString(scanner,
                "Enter Account Number (non-empty text): ");
        String accountType = readNonEmptyString(scanner,
                "Enter Account Type (e.g., Savings/Current): ");
        double balance = readNonNegativeDouble(scanner,
                "Enter Current Balance (number >= 0): ");

        String customerName = readNonEmptyString(scanner, "Enter Customer Name (non-empty text): ");
        String customerEmail = readEmail(scanner, "Enter Customer Email (must contain @): ");
        String customerPhone = readNonEmptyString(scanner,
                "Enter Customer Phone Number (non-empty text): ");

        String transactionId = readNonEmptyString(scanner,
                "Enter Transaction ID (non-empty text): ");
        String transactionType = readNonEmptyString(scanner,
                "Enter Transaction Type (e.g., Deposit/Withdrawal): ");
        double transactionAmount = readPositiveDouble(scanner,
                "Enter Transaction Amount (number > 0): ");

        double depositAmount = readPositiveDouble(scanner,
                "Enter Deposit Amount (number > 0): ");
        String depositDate = readNonEmptyString(scanner,
                "Enter Deposit Date (e.g., 2025-11-22): ");

        double withdrawalAmount = readPositiveDouble(scanner,
                "Enter Withdrawal Amount (number > 0): ");
        String withdrawalDate = readNonEmptyString(scanner,
                "Enter Withdrawal Date (e.g., 2025-11-22): ");

        double loanAmount = readPositiveDouble(scanner,
                "Enter Loan Amount (number > 0): ");
        double interestRate = readPositiveDouble(scanner,
                "Enter Interest Rate (number > 0): ");
        double duration = readPositiveDouble(scanner,
                "Enter Duration (in years, number > 0): ");

        double paymentAmount = readPositiveDouble(scanner,
                "Enter Payment Amount (number > 0): ");
        String paymentDate = readNonEmptyString(scanner,
                "Enter Payment Date (e.g., 2025-11-22): ");

        AccountRecord record = new AccountRecord(
                entityId, createdDate, updatedDate,
                bankName, branchCode, bankAddress,
                accountNumber, accountType, balance,
                customerName, customerEmail, customerPhone,
                transactionId, transactionType, transactionAmount,
                depositAmount, depositDate,
                withdrawalAmount, withdrawalDate,
                loanAmount, interestRate, duration,
                paymentAmount, paymentDate
        );

        double interest = record.calculateInterest();

        printlnWithId("=== Account Record Summary ===");
        printlnWithId("Entity ID: " + record.getId());
        printlnWithId("Bank: " + record.getBankName() + " (" + record.getBranchCode() + ")");
        printlnWithId("Account: " + record.getAccountNumber() + " - " + record.getAccountType());
        printlnWithId("Customer: " + record.getCustomerName() + " (" + record.getEmail() + ")");
        printlnWithId("Transaction: " + record.getTransactionId() + " - " + record.getTransactionType()
                + " Amount: " + record.getAmount());
        printlnWithId("Deposit: " + record.getDepositAmount() + " on " + record.getDepositDate());
        printlnWithId("Withdrawal: " + record.getWithdrawalAmount() + " on " + record.getWithdrawalDate());
        printlnWithId("Loan Amount: " + record.getLoanAmount());
        printlnWithId("Interest Rate: " + record.getInterestRate());
        printlnWithId("Duration: " + record.getDuration());
        printlnWithId("Calculated Interest: " + interest);
    }

    private static void printlnWithId(String msg) {
        System.out.println(msg + " [" + STUDENT_ID + "]");
    }

    private static void printWithId(String msg) {
        System.out.print(msg + " [" + STUDENT_ID + "] ");
    }

    private static int readPositiveInt(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            if (!scanner.hasNextInt()) {
                scanner.nextLine();
                printlnWithId("Invalid input: please enter a whole number > 0. Attempts left: " + (3 - attempt));
                continue;
            }
            int value = scanner.nextInt();
            scanner.nextLine();
            if (value > 0) {
                return value;
            }
            printlnWithId("Value must be > 0. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return 0;
    }

    private static double readPositiveDouble(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            if (!scanner.hasNextDouble()) {
                scanner.nextLine();
                printlnWithId("Invalid input: please enter a number > 0. Attempts left: " + (3 - attempt));
                continue;
            }
            double value = scanner.nextDouble();
            scanner.nextLine();
            if (value > 0) {
                return value;
            }
            printlnWithId("Value must be > 0. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return 0.0;
    }

    private static double readNonNegativeDouble(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            if (!scanner.hasNextDouble()) {
                scanner.nextLine();
                printlnWithId("Invalid input: please enter a number >= 0. Attempts left: " + (3 - attempt));
                continue;
            }
            double value = scanner.nextDouble();
            scanner.nextLine();
            if (value >= 0) {
                return value;
            }
            printlnWithId("Value must be >= 0. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return 0.0;
    }

    private static String readNonEmptyString(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            String value = scanner.nextLine();
            if (value != null && !value.trim().isEmpty()) {
                return value.trim();
            }
            printlnWithId("Input must not be empty. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return null;
    }

    private static String readEmail(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            String value = scanner.nextLine().trim();
            if (!value.isEmpty() && value.contains("@")) {
                return value;
            }
            printlnWithId("Invalid email: must contain '@'. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return null;
    }
}
