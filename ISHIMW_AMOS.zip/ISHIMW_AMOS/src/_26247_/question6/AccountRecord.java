package _26247_.question6;

// Entity
class Entity {
    private int id;
    private String createdDate;
    private String updatedDate;

    public Entity(int id, String createdDate, String updatedDate) {
        if (id <= 0) {
            throw new IllegalArgumentException("id must be > 0");
        }
        this.id = id;
        this.createdDate = createdDate;
        this.updatedDate = updatedDate;
    }

    protected boolean isNullOrEmpty(String value) {
        return value == null || value.trim().isEmpty();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("id must be > 0");
        }
        this.id = id;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(String updatedDate) {
        this.updatedDate = updatedDate;
    }
}

// Bank
class Bank extends Entity {
    private String bankName;
    private String branchCode;
    private String address;

    public Bank(int id, String createdDate, String updatedDate,
                String bankName, String branchCode, String address) {
        super(id, createdDate, updatedDate);
        if (isNullOrEmpty(bankName) || isNullOrEmpty(address)) {
            throw new IllegalArgumentException("bankName and address must not be empty");
        }
        if (isNullOrEmpty(branchCode) || branchCode.length() < 3) {
            throw new IllegalArgumentException("branchCode must be at least 3 chars");
        }
        this.bankName = bankName;
        this.branchCode = branchCode;
        this.address = address;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        if (isNullOrEmpty(bankName)) {
            throw new IllegalArgumentException("bankName must not be empty");
        }
        this.bankName = bankName;
    }

    public String getBranchCode() {
        return branchCode;
    }

    public void setBranchCode(String branchCode) {
        if (isNullOrEmpty(branchCode) || branchCode.length() < 3) {
            throw new IllegalArgumentException("branchCode must be at least 3 chars");
        }
        this.branchCode = branchCode;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        if (isNullOrEmpty(address)) {
            throw new IllegalArgumentException("address must not be empty");
        }
        this.address = address;
    }
}

// Account
class Account extends Bank {
    private String accountNumber;
    private String accountType;
    private double balance;

    public Account(int id, String createdDate, String updatedDate,
                   String bankName, String branchCode, String address,
                   String accountNumber, String accountType, double balance) {
        super(id, createdDate, updatedDate, bankName, branchCode, address);
        if (isNullOrEmpty(accountNumber) || isNullOrEmpty(accountType)) {
            throw new IllegalArgumentException("accountNumber and accountType must not be empty");
        }
        if (balance < 0) {
            throw new IllegalArgumentException("balance must be >= 0");
        }
        this.accountNumber = accountNumber;
        this.accountType = accountType;
        this.balance = balance;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        if (isNullOrEmpty(accountNumber)) {
            throw new IllegalArgumentException("accountNumber must not be empty");
        }
        this.accountNumber = accountNumber;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        if (isNullOrEmpty(accountType)) {
            throw new IllegalArgumentException("accountType must not be empty");
        }
        this.accountType = accountType;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        if (balance < 0) {
            throw new IllegalArgumentException("balance must be >= 0");
        }
        this.balance = balance;
    }
}

// Customer
class Customer extends Account {
    private String customerName;
    private String email;
    private String phoneNumber;

    public Customer(int id, String createdDate, String updatedDate,
                    String bankName, String branchCode, String address,
                    String accountNumber, String accountType, double balance,
                    String customerName, String email, String phoneNumber) {
        super(id, createdDate, updatedDate, bankName, branchCode, address,
              accountNumber, accountType, balance);
        if (isNullOrEmpty(customerName)) {
            throw new IllegalArgumentException("customerName must not be empty");
        }
        if (isNullOrEmpty(email) || !email.contains("@")) {
            throw new IllegalArgumentException("Invalid email");
        }
        if (isNullOrEmpty(phoneNumber)) {
            throw new IllegalArgumentException("phoneNumber must not be empty");
        }
        this.customerName = customerName;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        if (isNullOrEmpty(customerName)) {
            throw new IllegalArgumentException("customerName must not be empty");
        }
        this.customerName = customerName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        if (isNullOrEmpty(email) || !email.contains("@")) {
            throw new IllegalArgumentException("Invalid email");
        }
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        if (isNullOrEmpty(phoneNumber)) {
            throw new IllegalArgumentException("phoneNumber must not be empty");
        }
        this.phoneNumber = phoneNumber;
    }
}

// Transaction
class Transaction extends Customer {
    private String transactionId;
    private String transactionType;
    private double amount;

    public Transaction(int id, String createdDate, String updatedDate,
                       String bankName, String branchCode, String address,
                       String accountNumber, String accountType, double balance,
                       String customerName, String email, String phoneNumber,
                       String transactionId, String transactionType, double amount) {
        super(id, createdDate, updatedDate, bankName, branchCode, address,
              accountNumber, accountType, balance,
              customerName, email, phoneNumber);
        if (isNullOrEmpty(transactionId) || isNullOrEmpty(transactionType)) {
            throw new IllegalArgumentException("transactionId and transactionType must not be empty");
        }
        if (amount <= 0) {
            throw new IllegalArgumentException("amount must be > 0");
        }
        this.transactionId = transactionId;
        this.transactionType = transactionType;
        this.amount = amount;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        if (isNullOrEmpty(transactionId)) {
            throw new IllegalArgumentException("transactionId must not be empty");
        }
        this.transactionId = transactionId;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        if (isNullOrEmpty(transactionType)) {
            throw new IllegalArgumentException("transactionType must not be empty");
        }
        this.transactionType = transactionType;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("amount must be > 0");
        }
        this.amount = amount;
    }
}

// Deposit
class Deposit extends Transaction {
    private double depositAmount;
    private String depositDate;

    public Deposit(int id, String createdDate, String updatedDate,
                   String bankName, String branchCode, String address,
                   String accountNumber, String accountType, double balance,
                   String customerName, String email, String phoneNumber,
                   String transactionId, String transactionType, double amount,
                   double depositAmount, String depositDate) {
        super(id, createdDate, updatedDate, bankName, branchCode, address,
              accountNumber, accountType, balance,
              customerName, email, phoneNumber,
              transactionId, transactionType, amount);
        if (depositAmount <= 0) {
            throw new IllegalArgumentException("depositAmount must be > 0");
        }
        if (isNullOrEmpty(depositDate)) {
            throw new IllegalArgumentException("depositDate must not be empty");
        }
        this.depositAmount = depositAmount;
        this.depositDate = depositDate;
    }

    public double getDepositAmount() {
        return depositAmount;
    }

    public void setDepositAmount(double depositAmount) {
        if (depositAmount <= 0) {
            throw new IllegalArgumentException("depositAmount must be > 0");
        }
        this.depositAmount = depositAmount;
    }

    public String getDepositDate() {
        return depositDate;
    }

    public void setDepositDate(String depositDate) {
        if (isNullOrEmpty(depositDate)) {
            throw new IllegalArgumentException("depositDate must not be empty");
        }
        this.depositDate = depositDate;
    }
}

// Withdrawal
class Withdrawal extends Deposit {
    private double withdrawalAmount;
    private String withdrawalDate;

    public Withdrawal(int id, String createdDate, String updatedDate,
                      String bankName, String branchCode, String address,
                      String accountNumber, String accountType, double balance,
                      String customerName, String email, String phoneNumber,
                      String transactionId, String transactionType, double amount,
                      double depositAmount, String depositDate,
                      double withdrawalAmount, String withdrawalDate) {
        super(id, createdDate, updatedDate, bankName, branchCode, address,
              accountNumber, accountType, balance,
              customerName, email, phoneNumber,
              transactionId, transactionType, amount,
              depositAmount, depositDate);
        if (withdrawalAmount <= 0) {
            throw new IllegalArgumentException("withdrawalAmount must be > 0");
        }
        if (isNullOrEmpty(withdrawalDate)) {
            throw new IllegalArgumentException("withdrawalDate must not be empty");
        }
        this.withdrawalAmount = withdrawalAmount;
        this.withdrawalDate = withdrawalDate;
    }

    public double getWithdrawalAmount() {
        return withdrawalAmount;
    }

    public void setWithdrawalAmount(double withdrawalAmount) {
        if (withdrawalAmount <= 0) {
            throw new IllegalArgumentException("withdrawalAmount must be > 0");
        }
        this.withdrawalAmount = withdrawalAmount;
    }

    public String getWithdrawalDate() {
        return withdrawalDate;
    }

    public void setWithdrawalDate(String withdrawalDate) {
        if (isNullOrEmpty(withdrawalDate)) {
            throw new IllegalArgumentException("withdrawalDate must not be empty");
        }
        this.withdrawalDate = withdrawalDate;
    }
}

// Loan
class Loan extends Withdrawal {
    private double loanAmount;
    private double interestRate;
    private double duration;

    public Loan(int id, String createdDate, String updatedDate,
                String bankName, String branchCode, String address,
                String accountNumber, String accountType, double balance,
                String customerName, String email, String phoneNumber,
                String transactionId, String transactionType, double amount,
                double depositAmount, String depositDate,
                double withdrawalAmount, String withdrawalDate,
                double loanAmount, double interestRate, double duration) {
        super(id, createdDate, updatedDate, bankName, branchCode, address,
              accountNumber, accountType, balance,
              customerName, email, phoneNumber,
              transactionId, transactionType, amount,
              depositAmount, depositDate,
              withdrawalAmount, withdrawalDate);
        if (loanAmount <= 0 || interestRate <= 0 || duration <= 0) {
            throw new IllegalArgumentException("loanAmount, interestRate and duration must be > 0");
        }
        this.loanAmount = loanAmount;
        this.interestRate = interestRate;
        this.duration = duration;
    }

    public double getLoanAmount() {
        return loanAmount;
    }

    public void setLoanAmount(double loanAmount) {
        if (loanAmount <= 0) {
            throw new IllegalArgumentException("loanAmount must be > 0");
        }
        this.loanAmount = loanAmount;
    }

    public double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(double interestRate) {
        if (interestRate <= 0) {
            throw new IllegalArgumentException("interestRate must be > 0");
        }
        this.interestRate = interestRate;
    }

    public double getDuration() {
        return duration;
    }

    public void setDuration(double duration) {
        if (duration <= 0) {
            throw new IllegalArgumentException("duration must be > 0");
        }
        this.duration = duration;
    }
}

// Payment
class Payment extends Loan {
    private double paymentAmount;
    private String paymentDate;

    public Payment(int id, String createdDate, String updatedDate,
                   String bankName, String branchCode, String address,
                   String accountNumber, String accountType, double balance,
                   String customerName, String email, String phoneNumber,
                   String transactionId, String transactionType, double amount,
                   double depositAmount, String depositDate,
                   double withdrawalAmount, String withdrawalDate,
                   double loanAmount, double interestRate, double duration,
                   double paymentAmount, String paymentDate) {
        super(id, createdDate, updatedDate, bankName, branchCode, address,
              accountNumber, accountType, balance,
              customerName, email, phoneNumber,
              transactionId, transactionType, amount,
              depositAmount, depositDate,
              withdrawalAmount, withdrawalDate,
              loanAmount, interestRate, duration);
        if (paymentAmount <= 0) {
            throw new IllegalArgumentException("paymentAmount must be > 0");
        }
        if (isNullOrEmpty(paymentDate)) {
            throw new IllegalArgumentException("paymentDate must not be empty");
        }
        this.paymentAmount = paymentAmount;
        this.paymentDate = paymentDate;
    }

    public double getPaymentAmount() {
        return paymentAmount;
    }

    public void setPaymentAmount(double paymentAmount) {
        if (paymentAmount <= 0) {
            throw new IllegalArgumentException("paymentAmount must be > 0");
        }
        this.paymentAmount = paymentAmount;
    }

    public String getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(String paymentDate) {
        if (isNullOrEmpty(paymentDate)) {
            throw new IllegalArgumentException("paymentDate must not be empty");
        }
        this.paymentDate = paymentDate;
    }
}

// Final AccountRecord
public final class AccountRecord extends Payment {

    public AccountRecord(int id, String createdDate, String updatedDate,
                         String bankName, String branchCode, String address,
                         String accountNumber, String accountType, double balance,
                         String customerName, String email, String phoneNumber,
                         String transactionId, String transactionType, double amount,
                         double depositAmount, String depositDate,
                         double withdrawalAmount, String withdrawalDate,
                         double loanAmount, double interestRate, double duration,
                         double paymentAmount, String paymentDate) {
        super(id, createdDate, updatedDate, bankName, branchCode, address,
              accountNumber, accountType, balance,
              customerName, email, phoneNumber,
              transactionId, transactionType, amount,
              depositAmount, depositDate,
              withdrawalAmount, withdrawalDate,
              loanAmount, interestRate, duration,
              paymentAmount, paymentDate);
    }

    // calculateInterest() = (loanAmount × interestRate × duration)/100
    public double calculateInterest() {
        return (getLoanAmount() * getInterestRate() * getDuration()) / 100.0;
    }
}
