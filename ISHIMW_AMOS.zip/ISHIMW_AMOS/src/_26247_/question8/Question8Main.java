package _26247_.question8;

import java.util.Scanner;

public class Question8Main {

    private static final String STUDENT_ID = "26247";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int maxAttempts = 3;

        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            try {
                runProgram(scanner);
                break;
            } catch (Exception ex) {
                printlnWithId("ERROR: " + ex.getMessage());
                if (attempt == maxAttempts) {
                    printlnWithId("Maximum attempts (" + maxAttempts + ") reached. Exiting program.");
                } else {
                    printlnWithId("Please re-enter all details carefully. Attempt "
                            + (attempt + 1) + " of " + maxAttempts + ".");
                }
            }
        }

        scanner.close();
    }

    private static void runProgram(Scanner scanner) {
        printlnWithId("=== Question 8: Library Management System ===");

        int entityId = readPositiveInt(scanner, "Enter Entity ID (integer > 0): ");
        String createdDate = readNonEmptyString(scanner, "Enter Created Date (e.g., 2025-11-22): ");
        String updatedDate = readNonEmptyString(scanner, "Enter Updated Date (e.g., 2025-11-22): ");

        String libraryName = readNonEmptyString(scanner, "Enter Library Name (non-empty text): ");
        String location = readNonEmptyString(scanner, "Enter Library Location (non-empty text): ");
        String libraryPhone = readNonEmptyString(scanner, "Enter Library Phone Number (non-empty text): ");

        String sectionName = readNonEmptyString(scanner, "Enter Section Name (non-empty text): ");
        String sectionCode = readNonEmptyString(scanner,
                "Enter Section Code (at least 3 characters): ");

        String title = readNonEmptyString(scanner, "Enter Book Title (non-empty text): ");
        String author = readNonEmptyString(scanner, "Enter Book Author (non-empty text): ");
        String isbn = readNonEmptyString(scanner,
                "Enter Book ISBN (at least 10 characters): ");

        String memberName = readNonEmptyString(scanner, "Enter Member Name (non-empty text): ");
        int memberId = readPositiveInt(scanner, "Enter Member ID (integer > 0): ");
        String memberContact = readNonEmptyString(scanner,
                "Enter Member Contact Number (non-empty text): ");

        String borrowDate = readNonEmptyString(scanner,
                "Enter Borrow Date (e.g., 2025-11-22): ");
        String returnDate = readNonEmptyString(scanner,
                "Enter Return Date (e.g., 2025-11-25): ");

        double fineAmount = readNonNegativeDouble(scanner,
                "Enter Fine Amount per Day (number >= 0): ");
        int daysLate = readNonNegativeInt(scanner,
                "Enter Days Late (integer >= 0): ");

        String paymentDate = readNonEmptyString(scanner,
                "Enter Payment Date (e.g., 2025-11-22): ");
        String paymentMode = readNonEmptyString(scanner,
                "Enter Payment Mode (e.g., Cash/Card): ");

        double totalFineInput = readPositiveDouble(scanner,
                "Enter Total Fine (number > 0): ");

        LibraryRecord record = new LibraryRecord(
                entityId, createdDate, updatedDate,
                libraryName, location, libraryPhone,
                sectionName, sectionCode,
                title, author, isbn,
                memberName, memberId, memberContact,
                borrowDate, returnDate,
                fineAmount, daysLate,
                paymentDate, paymentMode,
                totalFineInput
        );

        double calculatedFine = record.calculateFine();

        printlnWithId("=== Library Record Summary ===");
        printlnWithId("Entity ID: " + record.getId());
        printlnWithId("Library: " + record.getLibraryName() + " (" + record.getLocation() + ")");
        printlnWithId("Section: " + record.getSectionName() + " (" + record.getSectionCode() + ")");
        printlnWithId("Book: " + record.getTitle() + " by " + record.getAuthor() + " (ISBN: " + record.getIsbn() + ")");
        printlnWithId("Member: " + record.getMemberName() + " (ID: " + record.getMemberId() + ")");
        printlnWithId("Borrow Date: " + record.getBorrowDate() + " | Return Date: " + record.getReturnDate());
        printlnWithId("Fine Amount per Day: " + record.getFineAmount());
        printlnWithId("Days Late: " + record.getDaysLate());
        printlnWithId("Total Fine (calculated): " + calculatedFine);
    }

    private static void printlnWithId(String msg) {
        System.out.println(msg + " [" + STUDENT_ID + "]");
    }

    private static void printWithId(String msg) {
        System.out.print(msg + " [" + STUDENT_ID + "] ");
    }

    private static int readPositiveInt(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            if (!scanner.hasNextInt()) {
                scanner.nextLine();
                printlnWithId("Invalid input: please enter a whole number > 0. Attempts left: " + (3 - attempt));
                continue;
            }
            int value = scanner.nextInt();
            scanner.nextLine();
            if (value > 0) {
                return value;
            }
            printlnWithId("Value must be > 0. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return 0;
    }

    private static int readNonNegativeInt(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            if (!scanner.hasNextInt()) {
                scanner.nextLine();
                printlnWithId("Invalid input: please enter a whole number >= 0. Attempts left: " + (3 - attempt));
                continue;
            }
            int value = scanner.nextInt();
            scanner.nextLine();
            if (value >= 0) {
                return value;
            }
            printlnWithId("Value must be >= 0. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return 0;
    }

    private static double readPositiveDouble(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            if (!scanner.hasNextDouble()) {
                scanner.nextLine();
                printlnWithId("Invalid input: please enter a number > 0. Attempts left: " + (3 - attempt));
                continue;
            }
            double value = scanner.nextDouble();
            scanner.nextLine();
            if (value > 0) {
                return value;
            }
            printlnWithId("Value must be > 0. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return 0.0;
    }

    private static double readNonNegativeDouble(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            if (!scanner.hasNextDouble()) {
                scanner.nextLine();
                printlnWithId("Invalid input: please enter a number >= 0. Attempts left: " + (3 - attempt));
                continue;
            }
            double value = scanner.nextDouble();
            scanner.nextLine();
            if (value >= 0) {
                return value;
            }
            printlnWithId("Value must be >= 0. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return 0.0;
    }

    private static String readNonEmptyString(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            String value = scanner.nextLine();
            if (value != null && !value.trim().isEmpty()) {
                return value.trim();
            }
            printlnWithId("Input must not be empty. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return null;
    }
}

