package _26247_.question8;

// Entity
class Entity {
    private int id;
    private String createdDate;
    private String updatedDate;

    public Entity(int id, String createdDate, String updatedDate) {
        if (id <= 0) {
            throw new IllegalArgumentException("id must be > 0");
        }
        this.id = id;
        this.createdDate = createdDate;
        this.updatedDate = updatedDate;
    }

    protected boolean isNullOrEmpty(String value) {
        return value == null || value.trim().isEmpty();
    }

    protected void validatePhone(String phone) {
        if (isNullOrEmpty(phone)) {
            throw new IllegalArgumentException("phoneNumber must not be empty");
        }
    }

    public int getId() { return id; }
    public void setId(int id) { if (id <= 0) throw new IllegalArgumentException("id must be > 0"); this.id = id; }

    public String getCreatedDate() { return createdDate; }
    public void setCreatedDate(String createdDate) { this.createdDate = createdDate; }

    public String getUpdatedDate() { return updatedDate; }
    public void setUpdatedDate(String updatedDate) { this.updatedDate = updatedDate; }
}

// Library
class Library extends Entity {
    private String libraryName;
    private String location;
    private String phoneNumber;

    public Library(int id, String createdDate, String updatedDate,
                   String libraryName, String location, String phoneNumber) {
        super(id, createdDate, updatedDate);
        if (isNullOrEmpty(libraryName) || isNullOrEmpty(location)) {
            throw new IllegalArgumentException("libraryName and location must not be empty");
        }
        validatePhone(phoneNumber);
        this.libraryName = libraryName;
        this.location = location;
        this.phoneNumber = phoneNumber;
    }

    public String getLibraryName() { return libraryName; }
    public void setLibraryName(String libraryName) {
        if (isNullOrEmpty(libraryName)) throw new IllegalArgumentException("libraryName must not be empty");
        this.libraryName = libraryName;
    }

    public String getLocation() { return location; }
    public void setLocation(String location) {
        if (isNullOrEmpty(location)) throw new IllegalArgumentException("location must not be empty");
        this.location = location;
    }

    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) { validatePhone(phoneNumber); this.phoneNumber = phoneNumber; }
}

// Section
class Section extends Library {
    private String sectionName;
    private String sectionCode;

    public Section(int id, String createdDate, String updatedDate,
                   String libraryName, String location, String phoneNumber,
                   String sectionName, String sectionCode) {
        super(id, createdDate, updatedDate, libraryName, location, phoneNumber);
        if (isNullOrEmpty(sectionName)) {
            throw new IllegalArgumentException("sectionName must not be empty");
        }
        if (isNullOrEmpty(sectionCode) || sectionCode.length() < 3) {
            throw new IllegalArgumentException("sectionCode must be at least 3 chars");
        }
        this.sectionName = sectionName;
        this.sectionCode = sectionCode;
    }

    public String getSectionName() { return sectionName; }
    public void setSectionName(String sectionName) {
        if (isNullOrEmpty(sectionName)) throw new IllegalArgumentException("sectionName must not be empty");
        this.sectionName = sectionName;
    }

    public String getSectionCode() { return sectionCode; }
    public void setSectionCode(String sectionCode) {
        if (isNullOrEmpty(sectionCode) || sectionCode.length() < 3) throw new IllegalArgumentException("sectionCode must be at least 3 chars");
        this.sectionCode = sectionCode;
    }
}

// Book
class Book extends Section {
    private String title;
    private String author;
    private String isbn;

    public Book(int id, String createdDate, String updatedDate,
                String libraryName, String location, String phoneNumber,
                String sectionName, String sectionCode,
                String title, String author, String isbn) {
        super(id, createdDate, updatedDate, libraryName, location, phoneNumber,
              sectionName, sectionCode);
        if (isNullOrEmpty(title) || isNullOrEmpty(author)) {
            throw new IllegalArgumentException("title and author must not be empty");
        }
        if (isNullOrEmpty(isbn) || isbn.length() < 10) {
            throw new IllegalArgumentException("ISBN must be at least 10 chars");
        }
        this.title = title;
        this.author = author;
        this.isbn = isbn;
    }

    public String getTitle() { return title; }
    public void setTitle(String title) {
        if (isNullOrEmpty(title)) throw new IllegalArgumentException("title must not be empty");
        this.title = title;
    }

    public String getAuthor() { return author; }
    public void setAuthor(String author) {
        if (isNullOrEmpty(author)) throw new IllegalArgumentException("author must not be empty");
        this.author = author;
    }

    public String getIsbn() { return isbn; }
    public void setIsbn(String isbn) {
        if (isNullOrEmpty(isbn) || isbn.length() < 10) throw new IllegalArgumentException("ISBN must be at least 10 chars");
        this.isbn = isbn;
    }
}

// Member
class Member extends Book {
    private String memberName;
    private int memberId;
    private String contactNumber;

    public Member(int id, String createdDate, String updatedDate,
                  String libraryName, String location, String phoneNumber,
                  String sectionName, String sectionCode,
                  String title, String author, String isbn,
                  String memberName, int memberId, String contactNumber) {
        super(id, createdDate, updatedDate, libraryName, location, phoneNumber,
              sectionName, sectionCode,
              title, author, isbn);
        if (isNullOrEmpty(memberName)) {
            throw new IllegalArgumentException("memberName must not be empty");
        }
        if (memberId <= 0) {
            throw new IllegalArgumentException("memberId must be > 0");
        }
        validatePhone(contactNumber);
        this.memberName = memberName;
        this.memberId = memberId;
        this.contactNumber = contactNumber;
    }

    public String getMemberName() { return memberName; }
    public void setMemberName(String memberName) {
        if (isNullOrEmpty(memberName)) throw new IllegalArgumentException("memberName must not be empty");
        this.memberName = memberName;
    }

    public int getMemberId() { return memberId; }
    public void setMemberId(int memberId) {
        if (memberId <= 0) throw new IllegalArgumentException("memberId must be > 0");
        this.memberId = memberId;
    }

    public String getContactNumber() { return contactNumber; }
    public void setContactNumber(String contactNumber) { validatePhone(contactNumber); this.contactNumber = contactNumber; }
}

// Borrow
class Borrow extends Member {
    private String borrowDate;
    private String returnDate;

    public Borrow(int id, String createdDate, String updatedDate,
                  String libraryName, String location, String phoneNumber,
                  String sectionName, String sectionCode,
                  String title, String author, String isbn,
                  String memberName, int memberId, String contactNumber,
                  String borrowDate, String returnDate) {
        super(id, createdDate, updatedDate, libraryName, location, phoneNumber,
              sectionName, sectionCode,
              title, author, isbn,
              memberName, memberId, contactNumber);
        if (isNullOrEmpty(borrowDate) || isNullOrEmpty(returnDate)) {
            throw new IllegalArgumentException("borrowDate and returnDate must not be empty");
        }
        this.borrowDate = borrowDate;
        this.returnDate = returnDate;
    }

    public String getBorrowDate() { return borrowDate; }
    public void setBorrowDate(String borrowDate) {
        if (isNullOrEmpty(borrowDate)) throw new IllegalArgumentException("borrowDate must not be empty");
        this.borrowDate = borrowDate;
    }

    public String getReturnDate() { return returnDate; }
    public void setReturnDate(String returnDate) {
        if (isNullOrEmpty(returnDate)) throw new IllegalArgumentException("returnDate must not be empty");
        this.returnDate = returnDate;
    }
}

// Fine
class Fine extends Borrow {
    private double fineAmount;
    private int daysLate;

    public Fine(int id, String createdDate, String updatedDate,
                String libraryName, String location, String phoneNumber,
                String sectionName, String sectionCode,
                String title, String author, String isbn,
                String memberName, int memberId, String contactNumber,
                String borrowDate, String returnDate,
                double fineAmount, int daysLate) {
        super(id, createdDate, updatedDate, libraryName, location, phoneNumber,
              sectionName, sectionCode,
              title, author, isbn,
              memberName, memberId, contactNumber,
              borrowDate, returnDate);
        if (fineAmount < 0) {
            throw new IllegalArgumentException("fineAmount must be >= 0");
        }
        if (daysLate < 0) {
            throw new IllegalArgumentException("daysLate must be >= 0");
        }
        this.fineAmount = fineAmount;
        this.daysLate = daysLate;
    }

    public double getFineAmount() { return fineAmount; }
    public void setFineAmount(double fineAmount) {
        if (fineAmount < 0) throw new IllegalArgumentException("fineAmount must be >= 0");
        this.fineAmount = fineAmount;
    }

    public int getDaysLate() { return daysLate; }
    public void setDaysLate(int daysLate) {
        if (daysLate < 0) throw new IllegalArgumentException("daysLate must be >= 0");
        this.daysLate = daysLate;
    }
}

// Payment
class Payment extends Fine {
    private String paymentDate;
    private String paymentMode;

    public Payment(int id, String createdDate, String updatedDate,
                   String libraryName, String location, String phoneNumber,
                   String sectionName, String sectionCode,
                   String title, String author, String isbn,
                   String memberName, int memberId, String contactNumber,
                   String borrowDate, String returnDate,
                   double fineAmount, int daysLate,
                   String paymentDate, String paymentMode) {
        super(id, createdDate, updatedDate, libraryName, location, phoneNumber,
              sectionName, sectionCode,
              title, author, isbn,
              memberName, memberId, contactNumber,
              borrowDate, returnDate,
              fineAmount, daysLate);
        if (isNullOrEmpty(paymentDate) || isNullOrEmpty(paymentMode)) {
            throw new IllegalArgumentException("paymentDate and paymentMode must not be empty");
        }
        this.paymentDate = paymentDate;
        this.paymentMode = paymentMode;
    }

    public String getPaymentDate() { return paymentDate; }
    public void setPaymentDate(String paymentDate) {
        if (isNullOrEmpty(paymentDate)) throw new IllegalArgumentException("paymentDate must not be empty");
        this.paymentDate = paymentDate;
    }

    public String getPaymentMode() { return paymentMode; }
    public void setPaymentMode(String paymentMode) {
        if (isNullOrEmpty(paymentMode)) throw new IllegalArgumentException("paymentMode must not be empty");
        this.paymentMode = paymentMode;
    }
}

// Record
class Record extends Payment {
    private double totalFine;

    public Record(int id, String createdDate, String updatedDate,
                  String libraryName, String location, String phoneNumber,
                  String sectionName, String sectionCode,
                  String title, String author, String isbn,
                  String memberName, int memberId, String contactNumber,
                  String borrowDate, String returnDate,
                  double fineAmount, int daysLate,
                  String paymentDate, String paymentMode,
                  double totalFine) {
        super(id, createdDate, updatedDate, libraryName, location, phoneNumber,
              sectionName, sectionCode,
              title, author, isbn,
              memberName, memberId, contactNumber,
              borrowDate, returnDate,
              fineAmount, daysLate,
              paymentDate, paymentMode);
        if (totalFine <= 0) {
            throw new IllegalArgumentException("totalFine must be > 0");
        }
        this.totalFine = totalFine;
    }

    public double getTotalFine() { return totalFine; }
    public void setTotalFine(double totalFine) {
        if (totalFine <= 0) throw new IllegalArgumentException("totalFine must be > 0");
        this.totalFine = totalFine;
    }
}

// Final LibraryRecord
public final class LibraryRecord extends Record {

    public LibraryRecord(int id, String createdDate, String updatedDate,
                         String libraryName, String location, String phoneNumber,
                         String sectionName, String sectionCode,
                         String title, String author, String isbn,
                         String memberName, int memberId, String contactNumber,
                         String borrowDate, String returnDate,
                         double fineAmount, int daysLate,
                         String paymentDate, String paymentMode,
                         double totalFine) {
        super(id, createdDate, updatedDate, libraryName, location, phoneNumber,
              sectionName, sectionCode,
              title, author, isbn,
              memberName, memberId, contactNumber,
              borrowDate, returnDate,
              fineAmount, daysLate,
              paymentDate, paymentMode,
              totalFine);
    }

    // calculateFine() = fineAmount × daysLate
    public double calculateFine() {
        double calc = getFineAmount() * getDaysLate();
        setTotalFine(calc);
        return calc;
    }
}
