package _26247_.question7;

import java.util.Scanner;

public class Question7Main {

    private static final String STUDENT_ID = "26247";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int maxAttempts = 3;

        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            try {
                runProgram(scanner);
                break;
            } catch (Exception ex) {
                printlnWithId("ERROR: " + ex.getMessage());
                if (attempt == maxAttempts) {
                    printlnWithId("Maximum attempts (" + maxAttempts + ") reached. Exiting program.");
                } else {
                    printlnWithId("Please re-enter all details carefully. Attempt "
                            + (attempt + 1) + " of " + maxAttempts + ".");
                }
            }
        }

        scanner.close();
    }

    private static void runProgram(Scanner scanner) {
        printlnWithId("=== Question 7: Real Estate Management System ===");

        int entityId = readPositiveInt(scanner, "Enter Entity ID (integer > 0): ");
        String createdDate = readNonEmptyString(scanner, "Enter Created Date (e.g., 2025-11-22): ");
        String updatedDate = readNonEmptyString(scanner, "Enter Updated Date (e.g., 2025-11-22): ");

        String agencyName = readNonEmptyString(scanner, "Enter Agency Name (non-empty text): ");
        String location = readNonEmptyString(scanner, "Enter Agency Location (non-empty text): ");
        String agencyPhone = readNonEmptyString(scanner, "Enter Agency Phone Number (non-empty text): ");

        String agentName = readNonEmptyString(scanner, "Enter Agent Name (non-empty text): ");
        String agentEmail = readEmail(scanner, "Enter Agent Email (must contain @): ");
        String licenseNumber = readNonEmptyString(scanner,
                "Enter Agent License Number (non-empty text): ");

        String propertyCode = readNonEmptyString(scanner,
                "Enter Property Code (non-empty text): ");
        String propertyType = readNonEmptyString(scanner,
                "Enter Property Type (non-empty text): ");
        double price = readPositiveDouble(scanner,
                "Enter Property Price (number > 0): ");

        String sellerName = readNonEmptyString(scanner, "Enter Seller Name (non-empty text): ");
        String sellerContact = readNonEmptyString(scanner,
                "Enter Seller Contact Number (non-empty text): ");

        String buyerName = readNonEmptyString(scanner, "Enter Buyer Name (non-empty text): ");
        String buyerEmail = readEmail(scanner, "Enter Buyer Email (must contain @): ");

        String agreementDate = readNonEmptyString(scanner,
                "Enter Agreement Date (e.g., 2025-11-22): ");
        String terms = readNonEmptyString(scanner,
                "Enter Agreement Terms (non-empty text): ");

        double paymentAmount = readPositiveDouble(scanner,
                "Enter Payment Amount (number > 0): ");
        String paymentDate = readNonEmptyString(scanner,
                "Enter Payment Date (e.g., 2025-11-22): ");

        double commissionRate = readNonNegativeDouble(scanner,
                "Enter Commission Rate (percentage, number >= 0): ");
        double commissionAmountInput = readNonNegativeDouble(scanner,
                "Enter Initial Commission Amount (can be 0): ");

        RealEstateRecord record = new RealEstateRecord(
                entityId, createdDate, updatedDate,
                agencyName, location, agencyPhone,
                agentName, agentEmail, licenseNumber,
                propertyCode, propertyType, price,
                sellerName, sellerContact,
                buyerName, buyerEmail,
                agreementDate, terms,
                paymentAmount, paymentDate,
                commissionRate, commissionAmountInput
        );

        double commissionAmount = record.calculateCommission();

        printlnWithId("=== Real Estate Record Summary ===");
        printlnWithId("Entity ID: " + record.getId());
        printlnWithId("Agency: " + record.getAgencyName() + " (" + record.getLocation() + ")");
        printlnWithId("Agent: " + record.getAgentName());
        printlnWithId("Property: " + record.getPropertyCode() + " - " + record.getPropertyType()
                + " Price: " + record.getPrice());
        printlnWithId("Seller: " + record.getSellerName() + " Contact: " + record.getContactNumber());
        printlnWithId("Buyer: " + record.getBuyerName() + " (" + record.getEmail() + ")");
        printlnWithId("Agreement Date: " + record.getAgreementDate());
        printlnWithId("Payment Amount: " + record.getPaymentAmount());
        printlnWithId("Commission Rate: " + record.getCommissionRate());
        printlnWithId("Commission Amount: " + commissionAmount);
    }

    private static void printlnWithId(String msg) {
        System.out.println(msg + " [" + STUDENT_ID + "]");
    }

    private static void printWithId(String msg) {
        System.out.print(msg + " [" + STUDENT_ID + "] ");
    }

    private static int readPositiveInt(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            if (!scanner.hasNextInt()) {
                scanner.nextLine();
                printlnWithId("Invalid input: please enter a whole number > 0. Attempts left: " + (3 - attempt));
                continue;
            }
            int value = scanner.nextInt();
            scanner.nextLine();
            if (value > 0) {
                return value;
            }
            printlnWithId("Value must be > 0. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return 0;
    }

    private static double readPositiveDouble(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            if (!scanner.hasNextDouble()) {
                scanner.nextLine();
                printlnWithId("Invalid input: please enter a number > 0. Attempts left: " + (3 - attempt));
                continue;
            }
            double value = scanner.nextDouble();
            scanner.nextLine();
            if (value > 0) {
                return value;
            }
            printlnWithId("Value must be > 0. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return 0.0;
    }

    private static double readNonNegativeDouble(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            if (!scanner.hasNextDouble()) {
                scanner.nextLine();
                printlnWithId("Invalid input: please enter a number >= 0. Attempts left: " + (3 - attempt));
                continue;
            }
            double value = scanner.nextDouble();
            scanner.nextLine();
            if (value >= 0) {
                return value;
            }
            printlnWithId("Value must be >= 0. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return 0.0;
    }

    private static String readNonEmptyString(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            String value = scanner.nextLine();
            if (value != null && !value.trim().isEmpty()) {
                return value.trim();
            }
            printlnWithId("Input must not be empty. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return null;
    }

    private static String readEmail(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            String value = scanner.nextLine().trim();
            if (!value.isEmpty() && value.contains("@")) {
                return value;
            }
            printlnWithId("Invalid email: must contain '@'. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return null;
    }
}
