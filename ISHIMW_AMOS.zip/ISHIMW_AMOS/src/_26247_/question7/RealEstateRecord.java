package _26247_.question7;

// Entity
class Entity {
    private int id;
    private String createdDate;
    private String updatedDate;

    public Entity(int id, String createdDate, String updatedDate) {
        if (id <= 0) {
            throw new IllegalArgumentException("id must be > 0");
        }
        this.id = id;
        this.createdDate = createdDate;
        this.updatedDate = updatedDate;
    }

    protected boolean isNullOrEmpty(String value) {
        return value == null || value.trim().isEmpty();
    }

    protected void validatePhone(String phone) {
        if (isNullOrEmpty(phone)) {
            throw new IllegalArgumentException("phoneNumber must not be empty");
        }
    }

    protected void validateEmail(String email) {
        if (isNullOrEmpty(email) || !email.contains("@")) {
            throw new IllegalArgumentException("Invalid email format");
        }
    }

    public int getId() { return id; }
    public void setId(int id) {
        if (id <= 0) throw new IllegalArgumentException("id must be > 0");
        this.id = id;
    }

    public String getCreatedDate() { return createdDate; }
    public void setCreatedDate(String createdDate) { this.createdDate = createdDate; }

    public String getUpdatedDate() { return updatedDate; }
    public void setUpdatedDate(String updatedDate) { this.updatedDate = updatedDate; }
}

// Agency
class Agency extends Entity {
    private String agencyName;
    private String location;
    private String phoneNumber;

    public Agency(int id, String createdDate, String updatedDate,
                  String agencyName, String location, String phoneNumber) {
        super(id, createdDate, updatedDate);
        if (isNullOrEmpty(agencyName) || isNullOrEmpty(location)) {
            throw new IllegalArgumentException("agencyName and location must not be empty");
        }
        validatePhone(phoneNumber);
        this.agencyName = agencyName;
        this.location = location;
        this.phoneNumber = phoneNumber;
    }

    public String getAgencyName() { return agencyName; }
    public void setAgencyName(String agencyName) {
        if (isNullOrEmpty(agencyName)) throw new IllegalArgumentException("agencyName must not be empty");
        this.agencyName = agencyName;
    }

    public String getLocation() { return location; }
    public void setLocation(String location) {
        if (isNullOrEmpty(location)) throw new IllegalArgumentException("location must not be empty");
        this.location = location;
    }

    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) { validatePhone(phoneNumber); this.phoneNumber = phoneNumber; }
}

// Agent
class Agent extends Agency {
    private String agentName;
    private String email;
    private String licenseNumber;

    public Agent(int id, String createdDate, String updatedDate,
                 String agencyName, String location, String phoneNumber,
                 String agentName, String email, String licenseNumber) {
        super(id, createdDate, updatedDate, agencyName, location, phoneNumber);
        if (isNullOrEmpty(agentName) || isNullOrEmpty(licenseNumber)) {
            throw new IllegalArgumentException("agentName and licenseNumber must not be empty");
        }
        validateEmail(email);
        this.agentName = agentName;
        this.email = email;
        this.licenseNumber = licenseNumber;
    }

    public String getAgentName() { return agentName; }
    public void setAgentName(String agentName) {
        if (isNullOrEmpty(agentName)) throw new IllegalArgumentException("agentName must not be empty");
        this.agentName = agentName;
    }

    public String getEmail() { return email; }
    public void setEmail(String email) { validateEmail(email); this.email = email; }

    public String getLicenseNumber() { return licenseNumber; }
    public void setLicenseNumber(String licenseNumber) {
        if (isNullOrEmpty(licenseNumber)) throw new IllegalArgumentException("licenseNumber must not be empty");
        this.licenseNumber = licenseNumber;
    }
}

// Property
class Property extends Agent {
    private String propertyCode;
    private String propertyType;
    private double price;

    public Property(int id, String createdDate, String updatedDate,
                    String agencyName, String location, String phoneNumber,
                    String agentName, String email, String licenseNumber,
                    String propertyCode, String propertyType, double price) {
        super(id, createdDate, updatedDate, agencyName, location, phoneNumber,
              agentName, email, licenseNumber);
        if (isNullOrEmpty(propertyCode) || isNullOrEmpty(propertyType)) {
            throw new IllegalArgumentException("propertyCode and propertyType must not be empty");
        }
        if (price <= 0) {
            throw new IllegalArgumentException("price must be > 0");
        }
        this.propertyCode = propertyCode;
        this.propertyType = propertyType;
        this.price = price;
    }

    public String getPropertyCode() { return propertyCode; }
    public void setPropertyCode(String propertyCode) {
        if (isNullOrEmpty(propertyCode)) throw new IllegalArgumentException("propertyCode must not be empty");
        this.propertyCode = propertyCode;
    }

    public String getPropertyType() { return propertyType; }
    public void setPropertyType(String propertyType) {
        if (isNullOrEmpty(propertyType)) throw new IllegalArgumentException("propertyType must not be empty");
        this.propertyType = propertyType;
    }

    public double getPrice() { return price; }
    public void setPrice(double price) {
        if (price <= 0) throw new IllegalArgumentException("price must be > 0");
        this.price = price;
    }
}

// Seller
class Seller extends Property {
    private String sellerName;
    private String contactNumber;

    public Seller(int id, String createdDate, String updatedDate,
                  String agencyName, String location, String phoneNumber,
                  String agentName, String email, String licenseNumber,
                  String propertyCode, String propertyType, double price,
                  String sellerName, String contactNumber) {
        super(id, createdDate, updatedDate, agencyName, location, phoneNumber,
              agentName, email, licenseNumber,
              propertyCode, propertyType, price);
        if (isNullOrEmpty(sellerName) || isNullOrEmpty(contactNumber)) {
            throw new IllegalArgumentException("sellerName and contactNumber must not be empty");
        }
        this.sellerName = sellerName;
        this.contactNumber = contactNumber;
    }

    public String getSellerName() { return sellerName; }
    public void setSellerName(String sellerName) {
        if (isNullOrEmpty(sellerName)) throw new IllegalArgumentException("sellerName must not be empty");
        this.sellerName = sellerName;
    }

    public String getContactNumber() { return contactNumber; }
    public void setContactNumber(String contactNumber) {
        if (isNullOrEmpty(contactNumber)) throw new IllegalArgumentException("contactNumber must not be empty");
        this.contactNumber = contactNumber;
    }
}

// Buyer
class Buyer extends Seller {
    private String buyerName;
    private String email;

    public Buyer(int id, String createdDate, String updatedDate,
                 String agencyName, String location, String phoneNumber,
                 String agentName, String email, String licenseNumber,
                 String propertyCode, String propertyType, double price,
                 String sellerName, String contactNumber,
                 String buyerName, String buyerEmail) {
        super(id, createdDate, updatedDate, agencyName, location, phoneNumber,
              agentName, email, licenseNumber,
              propertyCode, propertyType, price,
              sellerName, contactNumber);
        if (isNullOrEmpty(buyerName)) {
            throw new IllegalArgumentException("buyerName must not be empty");
        }
        validateEmail(buyerEmail);
        this.buyerName = buyerName;
        this.email = buyerEmail;
    }

    public String getBuyerName() { return buyerName; }
    public void setBuyerName(String buyerName) {
        if (isNullOrEmpty(buyerName)) throw new IllegalArgumentException("buyerName must not be empty");
        this.buyerName = buyerName;
    }

    public String getEmail() { return email; }
    public void setEmail(String email) { validateEmail(email); this.email = email; }
}

// Agreement
class Agreement extends Buyer {
    private String agreementDate;
    private String terms;

    public Agreement(int id, String createdDate, String updatedDate,
                     String agencyName, String location, String phoneNumber,
                     String agentName, String email, String licenseNumber,
                     String propertyCode, String propertyType, double price,
                     String sellerName, String contactNumber,
                     String buyerName, String buyerEmail,
                     String agreementDate, String terms) {
        super(id, createdDate, updatedDate, agencyName, location, phoneNumber,
              agentName, email, licenseNumber,
              propertyCode, propertyType, price,
              sellerName, contactNumber,
              buyerName, buyerEmail);
        if (isNullOrEmpty(agreementDate) || isNullOrEmpty(terms)) {
            throw new IllegalArgumentException("agreementDate and terms must not be empty");
        }
        this.agreementDate = agreementDate;
        this.terms = terms;
    }

    public String getAgreementDate() { return agreementDate; }
    public void setAgreementDate(String agreementDate) {
        if (isNullOrEmpty(agreementDate)) throw new IllegalArgumentException("agreementDate must not be empty");
        this.agreementDate = agreementDate;
    }

    public String getTerms() { return terms; }
    public void setTerms(String terms) {
        if (isNullOrEmpty(terms)) throw new IllegalArgumentException("terms must not be empty");
        this.terms = terms;
    }
}

// Payment
class Payment extends Agreement {
    private double paymentAmount;
    private String paymentDate;

    public Payment(int id, String createdDate, String updatedDate,
                   String agencyName, String location, String phoneNumber,
                   String agentName, String email, String licenseNumber,
                   String propertyCode, String propertyType, double price,
                   String sellerName, String contactNumber,
                   String buyerName, String buyerEmail,
                   String agreementDate, String terms,
                   double paymentAmount, String paymentDate) {
        super(id, createdDate, updatedDate, agencyName, location, phoneNumber,
              agentName, email, licenseNumber,
              propertyCode, propertyType, price,
              sellerName, contactNumber,
              buyerName, buyerEmail,
              agreementDate, terms);
        if (paymentAmount <= 0) {
            throw new IllegalArgumentException("paymentAmount must be > 0");
        }
        if (isNullOrEmpty(paymentDate)) {
            throw new IllegalArgumentException("paymentDate must not be empty");
        }
        this.paymentAmount = paymentAmount;
        this.paymentDate = paymentDate;
    }

    public double getPaymentAmount() { return paymentAmount; }
    public void setPaymentAmount(double paymentAmount) {
        if (paymentAmount <= 0) throw new IllegalArgumentException("paymentAmount must be > 0");
        this.paymentAmount = paymentAmount;
    }

    public String getPaymentDate() { return paymentDate; }
    public void setPaymentDate(String paymentDate) {
        if (isNullOrEmpty(paymentDate)) throw new IllegalArgumentException("paymentDate must not be empty");
        this.paymentDate = paymentDate;
    }
}

// Commission
class Commission extends Payment {
    private double commissionRate; // rate >= 0
    private double commissionAmount;

    public Commission(int id, String createdDate, String updatedDate,
                      String agencyName, String location, String phoneNumber,
                      String agentName, String email, String licenseNumber,
                      String propertyCode, String propertyType, double price,
                      String sellerName, String contactNumber,
                      String buyerName, String buyerEmail,
                      String agreementDate, String terms,
                      double paymentAmount, String paymentDate,
                      double commissionRate, double commissionAmount) {
        super(id, createdDate, updatedDate, agencyName, location, phoneNumber,
              agentName, email, licenseNumber,
              propertyCode, propertyType, price,
              sellerName, contactNumber,
              buyerName, buyerEmail,
              agreementDate, terms,
              paymentAmount, paymentDate);
        if (commissionRate < 0) {
            throw new IllegalArgumentException("commissionRate must be >= 0");
        }
        if (commissionAmount < 0) {
            throw new IllegalArgumentException("commissionAmount must be >= 0");
        }
        this.commissionRate = commissionRate;
        this.commissionAmount = commissionAmount;
    }

    public double getCommissionRate() { return commissionRate; }
    public void setCommissionRate(double commissionRate) {
        if (commissionRate < 0) throw new IllegalArgumentException("commissionRate must be >= 0");
        this.commissionRate = commissionRate;
    }

    public double getCommissionAmount() { return commissionAmount; }
    public void setCommissionAmount(double commissionAmount) {
        if (commissionAmount < 0) throw new IllegalArgumentException("commissionAmount must be >= 0");
        this.commissionAmount = commissionAmount;
    }
}

// Final RealEstateRecord
public final class RealEstateRecord extends Commission {

    public RealEstateRecord(int id, String createdDate, String updatedDate,
                            String agencyName, String location, String phoneNumber,
                            String agentName, String email, String licenseNumber,
                            String propertyCode, String propertyType, double price,
                            String sellerName, String contactNumber,
                            String buyerName, String buyerEmail,
                            String agreementDate, String terms,
                            double paymentAmount, String paymentDate,
                            double commissionRate, double commissionAmount) {
        super(id, createdDate, updatedDate, agencyName, location, phoneNumber,
              agentName, email, licenseNumber,
              propertyCode, propertyType, price,
              sellerName, contactNumber,
              buyerName, buyerEmail,
              agreementDate, terms,
              paymentAmount, paymentDate,
              commissionRate, commissionAmount);
    }

    // calculateCommission() = (price × commissionRate)/100
    public double calculateCommission() {
        double calculated = (getPrice() * getCommissionRate()) / 100.0;
        setCommissionAmount(calculated);
        return calculated;
    }
}
