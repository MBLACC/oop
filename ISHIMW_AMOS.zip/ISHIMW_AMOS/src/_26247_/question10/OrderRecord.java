package _26247_.question10;

// Entity
class Entity {
    private int id;
    private String createdDate;
    private String updatedDate;

    public Entity(int id, String createdDate, String updatedDate) {
        if (id <= 0) {
            throw new IllegalArgumentException("id must be > 0");
        }
        this.id = id;
        this.createdDate = createdDate;
        this.updatedDate = updatedDate;
    }

    protected boolean isNullOrEmpty(String value) {
        return value == null || value.trim().isEmpty();
    }

    protected void validateEmail(String email) {
        if (isNullOrEmpty(email) || !email.contains("@")) {
            throw new IllegalArgumentException("Invalid email format");
        }
    }

    public int getId() { return id; }
    public void setId(int id) { if (id <= 0) throw new IllegalArgumentException("id must be > 0"); this.id = id; }

    public String getCreatedDate() { return createdDate; }
    public void setCreatedDate(String createdDate) { this.createdDate = createdDate; }

    public String getUpdatedDate() { return updatedDate; }
    public void setUpdatedDate(String updatedDate) { this.updatedDate = updatedDate; }
}

// Store
class Store extends Entity {
    private String storeName;
    private String address;
    private String email;

    public Store(int id, String createdDate, String updatedDate,
                 String storeName, String address, String email) {
        super(id, createdDate, updatedDate);
        if (isNullOrEmpty(storeName) || isNullOrEmpty(address)) {
            throw new IllegalArgumentException("storeName and address must not be empty");
        }
        validateEmail(email);
        this.storeName = storeName;
        this.address = address;
        this.email = email;
    }

    public String getStoreName() { return storeName; }
    public void setStoreName(String storeName) {
        if (isNullOrEmpty(storeName)) throw new IllegalArgumentException("storeName must not be empty");
        this.storeName = storeName;
    }

    public String getAddress() { return address; }
    public void setAddress(String address) {
        if (isNullOrEmpty(address)) throw new IllegalArgumentException("address must not be empty");
        this.address = address;
    }

    public String getEmail() { return email; }
    public void setEmail(String email) { validateEmail(email); this.email = email; }
}

// Category
class Category extends Store {
    private String categoryName;
    private String categoryCode;

    public Category(int id, String createdDate, String updatedDate,
                    String storeName, String address, String email,
                    String categoryName, String categoryCode) {
        super(id, createdDate, updatedDate, storeName, address, email);
        if (isNullOrEmpty(categoryName)) {
            throw new IllegalArgumentException("categoryName must not be empty");
        }
        if (isNullOrEmpty(categoryCode) || categoryCode.length() < 3) {
            throw new IllegalArgumentException("categoryCode must be at least 3 chars");
        }
        this.categoryName = categoryName;
        this.categoryCode = categoryCode;
    }

    public String getCategoryName() { return categoryName; }
    public void setCategoryName(String categoryName) {
        if (isNullOrEmpty(categoryName)) throw new IllegalArgumentException("categoryName must not be empty");
        this.categoryName = categoryName;
    }

    public String getCategoryCode() { return categoryCode; }
    public void setCategoryCode(String categoryCode) {
        if (isNullOrEmpty(categoryCode) || categoryCode.length() < 3) throw new IllegalArgumentException("categoryCode must be at least 3 chars");
        this.categoryCode = categoryCode;
    }
}

// Product
class Product extends Category {
    private String productName;
    private String productCode;
    private double price;

    public Product(int id, String createdDate, String updatedDate,
                   String storeName, String address, String email,
                   String categoryName, String categoryCode,
                   String productName, String productCode, double price) {
        super(id, createdDate, updatedDate, storeName, address, email,
              categoryName, categoryCode);
        if (isNullOrEmpty(productName) || isNullOrEmpty(productCode)) {
            throw new IllegalArgumentException("productName and productCode must not be empty");
        }
        if (price <= 0) {
            throw new IllegalArgumentException("price must be > 0");
        }
        this.productName = productName;
        this.productCode = productCode;
        this.price = price;
    }

    public String getProductName() { return productName; }
    public void setProductName(String productName) {
        if (isNullOrEmpty(productName)) throw new IllegalArgumentException("productName must not be empty");
        this.productName = productName;
    }

    public String getProductCode() { return productCode; }
    public void setProductCode(String productCode) {
        if (isNullOrEmpty(productCode)) throw new IllegalArgumentException("productCode must not be empty");
        this.productCode = productCode;
    }

    public double getPrice() { return price; }
    public void setPrice(double price) {
        if (price <= 0) throw new IllegalArgumentException("price must be > 0");
        this.price = price;
    }
}

// Customer
class Customer extends Product {
    private String customerName;
    private String contactNumber;
    private String addressLine;

    public Customer(int id, String createdDate, String updatedDate,
                    String storeName, String address, String email,
                    String categoryName, String categoryCode,
                    String productName, String productCode, double price,
                    String customerName, String contactNumber, String addressLine) {
        super(id, createdDate, updatedDate, storeName, address, email,
              categoryName, categoryCode,
              productName, productCode, price);
        if (isNullOrEmpty(customerName) || isNullOrEmpty(contactNumber) || isNullOrEmpty(addressLine)) {
            throw new IllegalArgumentException("Customer details must not be empty");
        }
        this.customerName = customerName;
        this.contactNumber = contactNumber;
        this.addressLine = addressLine;
    }

    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) {
        if (isNullOrEmpty(customerName)) throw new IllegalArgumentException("customerName must not be empty");
        this.customerName = customerName;
    }

    public String getContactNumber() { return contactNumber; }
    public void setContactNumber(String contactNumber) {
        if (isNullOrEmpty(contactNumber)) throw new IllegalArgumentException("contactNumber must not be empty");
        this.contactNumber = contactNumber;
    }

    public String getAddressLine() { return addressLine; }
    public void setAddressLine(String addressLine) {
        if (isNullOrEmpty(addressLine)) throw new IllegalArgumentException("address must not be empty");
        this.addressLine = addressLine;
    }
}

// Order
class Order extends Customer {
    private String orderDate;
    private String orderId;

    public Order(int id, String createdDate, String updatedDate,
                 String storeName, String address, String email,
                 String categoryName, String categoryCode,
                 String productName, String productCode, double price,
                 String customerName, String contactNumber, String addressLine,
                 String orderDate, String orderId) {
        super(id, createdDate, updatedDate, storeName, address, email,
              categoryName, categoryCode,
              productName, productCode, price,
              customerName, contactNumber, addressLine);
        if (isNullOrEmpty(orderDate) || isNullOrEmpty(orderId)) {
            throw new IllegalArgumentException("orderDate and orderId must not be empty");
        }
        this.orderDate = orderDate;
        this.orderId = orderId;
    }

    public String getOrderDate() { return orderDate; }
    public void setOrderDate(String orderDate) {
        if (isNullOrEmpty(orderDate)) throw new IllegalArgumentException("orderDate must not be empty");
        this.orderDate = orderDate;
    }

    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) {
        if (isNullOrEmpty(orderId)) throw new IllegalArgumentException("orderId must not be empty");
        this.orderId = orderId;
    }
}

// Payment
class Payment extends Order {
    private String paymentMethod;
    private String paymentStatus;

    public Payment(int id, String createdDate, String updatedDate,
                   String storeName, String address, String email,
                   String categoryName, String categoryCode,
                   String productName, String productCode, double price,
                   String customerName, String contactNumber, String addressLine,
                   String orderDate, String orderId,
                   String paymentMethod, String paymentStatus) {
        super(id, createdDate, updatedDate, storeName, address, email,
              categoryName, categoryCode,
              productName, productCode, price,
              customerName, contactNumber, addressLine,
              orderDate, orderId);
        if (isNullOrEmpty(paymentMethod) || isNullOrEmpty(paymentStatus)) {
            throw new IllegalArgumentException("paymentMethod and paymentStatus must not be empty");
        }
        this.paymentMethod = paymentMethod;
        this.paymentStatus = paymentStatus;
    }

    public String getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(String paymentMethod) {
        if (isNullOrEmpty(paymentMethod)) throw new IllegalArgumentException("paymentMethod must not be empty");
        this.paymentMethod = paymentMethod;
    }

    public String getPaymentStatus() { return paymentStatus; }
    public void setPaymentStatus(String paymentStatus) {
        if (isNullOrEmpty(paymentStatus)) throw new IllegalArgumentException("paymentStatus must not be empty");
        this.paymentStatus = paymentStatus;
    }
}

// Shipping
class Shipping extends Payment {
    private String shippingAddress;
    private double shippingCost;

    public Shipping(int id, String createdDate, String updatedDate,
                    String storeName, String address, String email,
                    String categoryName, String categoryCode,
                    String productName, String productCode, double price,
                    String customerName, String contactNumber, String addressLine,
                    String orderDate, String orderId,
                    String paymentMethod, String paymentStatus,
                    String shippingAddress, double shippingCost) {
        super(id, createdDate, updatedDate, storeName, address, email,
              categoryName, categoryCode,
              productName, productCode, price,
              customerName, contactNumber, addressLine,
              orderDate, orderId,
              paymentMethod, paymentStatus);
        if (isNullOrEmpty(shippingAddress)) {
            throw new IllegalArgumentException("shippingAddress must not be empty");
        }
        if (shippingCost < 0) {
            throw new IllegalArgumentException("shippingCost must be >= 0");
        }
        this.shippingAddress = shippingAddress;
        this.shippingCost = shippingCost;
    }

    public String getShippingAddress() { return shippingAddress; }
    public void setShippingAddress(String shippingAddress) {
        if (isNullOrEmpty(shippingAddress)) throw new IllegalArgumentException("shippingAddress must not be empty");
        this.shippingAddress = shippingAddress;
    }

    public double getShippingCost() { return shippingCost; }
    public void setShippingCost(double shippingCost) {
        if (shippingCost < 0) throw new IllegalArgumentException("shippingCost must be >= 0");
        this.shippingCost = shippingCost;
    }
}

// Invoice
class Invoice extends Shipping {
    private double totalAmount;

    public Invoice(int id, String createdDate, String updatedDate,
                   String storeName, String address, String email,
                   String categoryName, String categoryCode,
                   String productName, String productCode, double price,
                   String customerName, String contactNumber, String addressLine,
                   String orderDate, String orderId,
                   String paymentMethod, String paymentStatus,
                   String shippingAddress, double shippingCost,
                   double totalAmount) {
        super(id, createdDate, updatedDate, storeName, address, email,
              categoryName, categoryCode,
              productName, productCode, price,
              customerName, contactNumber, addressLine,
              orderDate, orderId,
              paymentMethod, paymentStatus,
              shippingAddress, shippingCost);
        if (totalAmount <= 0) {
            throw new IllegalArgumentException("totalAmount must be > 0");
        }
        this.totalAmount = totalAmount;
    }

    public double getTotalAmount() { return totalAmount; }
    public void setTotalAmount(double totalAmount) {
        if (totalAmount <= 0) throw new IllegalArgumentException("totalAmount must be > 0");
        this.totalAmount = totalAmount;
    }
}

// Final OrderRecord
public final class OrderRecord extends Invoice {

    public OrderRecord(int id, String createdDate, String updatedDate,
                       String storeName, String address, String email,
                       String categoryName, String categoryCode,
                       String productName, String productCode, double price,
                       String customerName, String contactNumber, String addressLine,
                       String orderDate, String orderId,
                       String paymentMethod, String paymentStatus,
                       String shippingAddress, double shippingCost,
                       double totalAmount) {
        super(id, createdDate, updatedDate, storeName, address, email,
              categoryName, categoryCode,
              productName, productCode, price,
              customerName, contactNumber, addressLine,
              orderDate, orderId,
              paymentMethod, paymentStatus,
              shippingAddress, shippingCost,
              totalAmount);
    }

    // calculateTotalAmount() = price + shippingCost
    public double calculateTotalAmount() {
        double calc = getPrice() + getShippingCost();
        setTotalAmount(calc);
        return calc;
    }
}
