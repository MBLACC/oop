package _26247_.question4;

// Entity
class Entity {
    private int id;
    private String createdDate;
    private String updatedDate;

    public Entity(int id, String createdDate, String updatedDate) {
        if (id <= 0) {
            throw new IllegalArgumentException("id must be > 0");
        }
        if (isNullOrEmpty(createdDate) || isNullOrEmpty(updatedDate)) {
            throw new IllegalArgumentException("Dates must not be null or empty");
        }
        this.id = id;
        this.createdDate = createdDate;
        this.updatedDate = updatedDate;
    }

    protected boolean isNullOrEmpty(String value) {
        return value == null || value.trim().isEmpty();
    }

    protected void validatePhone(String phone) {
        if (isNullOrEmpty(phone)) {
            throw new IllegalArgumentException("Phone must not be empty");
        }
    }

    protected void validateEmail(String email) {
        if (isNullOrEmpty(email) || !email.contains("@")) {
            throw new IllegalArgumentException("Invalid email format");
        }
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("id must be > 0");
        }
        this.id = id;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        if (isNullOrEmpty(createdDate)) {
            throw new IllegalArgumentException("createdDate must not be empty");
        }
        this.createdDate = createdDate;
    }

    public String getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(String updatedDate) {
        if (isNullOrEmpty(updatedDate)) {
            throw new IllegalArgumentException("updatedDate must not be empty");
        }
        this.updatedDate = updatedDate;
    }
}

// Hotel
class Hotel extends Entity {
    private String hotelName;
    private String address;
    private String phoneNumber;
    private String email;

    public Hotel(int id, String createdDate, String updatedDate,
                 String hotelName, String address, String phoneNumber, String email) {
        super(id, createdDate, updatedDate);
        if (isNullOrEmpty(hotelName) || isNullOrEmpty(address)) {
            throw new IllegalArgumentException("hotelName and address must not be empty");
        }
        validatePhone(phoneNumber);
        validateEmail(email);
        this.hotelName = hotelName;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.email = email;
    }

    public String getHotelName() {
        return hotelName;
    }

    public void setHotelName(String hotelName) {
        if (isNullOrEmpty(hotelName)) {
            throw new IllegalArgumentException("hotelName must not be empty");
        }
        this.hotelName = hotelName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        if (isNullOrEmpty(address)) {
            throw new IllegalArgumentException("address must not be empty");
        }
        this.address = address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        validatePhone(phoneNumber);
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        validateEmail(email);
        this.email = email;
    }
}

// Room
class Room extends Hotel {
    private String roomNumber;
    private String roomType;
    private double pricePerNight;

    public Room(int id, String createdDate, String updatedDate,
                String hotelName, String address, String phoneNumber, String email,
                String roomNumber, String roomType, double pricePerNight) {
        super(id, createdDate, updatedDate, hotelName, address, phoneNumber, email);
        if (isNullOrEmpty(roomNumber) || isNullOrEmpty(roomType)) {
            throw new IllegalArgumentException("roomNumber and roomType must not be empty");
        }
        if (pricePerNight <= 0) {
            throw new IllegalArgumentException("pricePerNight must be > 0");
        }
        this.roomNumber = roomNumber;
        this.roomType = roomType;
        this.pricePerNight = pricePerNight;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        if (isNullOrEmpty(roomNumber)) {
            throw new IllegalArgumentException("roomNumber must not be empty");
        }
        this.roomNumber = roomNumber;
    }

    public String getRoomType() {
        return roomType;
    }

    public void setRoomType(String roomType) {
        if (isNullOrEmpty(roomType)) {
            throw new IllegalArgumentException("roomType must not be empty");
        }
        this.roomType = roomType;
    }

    public double getPricePerNight() {
        return pricePerNight;
    }

    public void setPricePerNight(double pricePerNight) {
        if (pricePerNight <= 0) {
            throw new IllegalArgumentException("pricePerNight must be > 0");
        }
        this.pricePerNight = pricePerNight;
    }
}

// Customer
class Customer extends Room {
    private String customerName;
    private String customerEmail;
    private String contactNumber;

    public Customer(int id, String createdDate, String updatedDate,
                    String hotelName, String address, String phoneNumber, String email,
                    String roomNumber, String roomType, double pricePerNight,
                    String customerName, String customerEmail, String contactNumber) {
        super(id, createdDate, updatedDate, hotelName, address, phoneNumber, email,
              roomNumber, roomType, pricePerNight);
        if (isNullOrEmpty(customerName)) {
            throw new IllegalArgumentException("customerName must not be empty");
        }
        validateEmail(customerEmail);
        validatePhone(contactNumber);
        this.customerName = customerName;
        this.customerEmail = customerEmail;
        this.contactNumber = contactNumber;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        if (isNullOrEmpty(customerName)) {
            throw new IllegalArgumentException("customerName must not be empty");
        }
        this.customerName = customerName;
    }

    public String getCustomerEmail() {
        return customerEmail;
    }

    public void setCustomerEmail(String customerEmail) {
        validateEmail(customerEmail);
        this.customerEmail = customerEmail;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        validatePhone(contactNumber);
        this.contactNumber = contactNumber;
    }
}

// Booking
class Booking extends Customer {
    private String bookingDate;
    private String checkInDate;
    private String checkOutDate;

    public Booking(int id, String createdDate, String updatedDate,
                   String hotelName, String address, String phoneNumber, String email,
                   String roomNumber, String roomType, double pricePerNight,
                   String customerName, String customerEmail, String contactNumber,
                   String bookingDate, String checkInDate, String checkOutDate) {
        super(id, createdDate, updatedDate, hotelName, address, phoneNumber, email,
              roomNumber, roomType, pricePerNight,
              customerName, customerEmail, contactNumber);
        if (isNullOrEmpty(bookingDate) || isNullOrEmpty(checkInDate) || isNullOrEmpty(checkOutDate)) {
            throw new IllegalArgumentException("Booking and stay dates must not be empty");
        }
        this.bookingDate = bookingDate;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
    }

    public String getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(String bookingDate) {
        if (isNullOrEmpty(bookingDate)) {
            throw new IllegalArgumentException("bookingDate must not be empty");
        }
        this.bookingDate = bookingDate;
    }

    public String getCheckInDate() {
        return checkInDate;
    }

    public void setCheckInDate(String checkInDate) {
        if (isNullOrEmpty(checkInDate)) {
            throw new IllegalArgumentException("checkInDate must not be empty");
        }
        this.checkInDate = checkInDate;
    }

    public String getCheckOutDate() {
        return checkOutDate;
    }

    public void setCheckOutDate(String checkOutDate) {
        if (isNullOrEmpty(checkOutDate)) {
            throw new IllegalArgumentException("checkOutDate must not be empty");
        }
        this.checkOutDate = checkOutDate;
    }
}

// Service
class Service extends Booking {
    private String serviceName;
    private double serviceCost;

    public Service(int id, String createdDate, String updatedDate,
                   String hotelName, String address, String phoneNumber, String email,
                   String roomNumber, String roomType, double pricePerNight,
                   String customerName, String customerEmail, String contactNumber,
                   String bookingDate, String checkInDate, String checkOutDate,
                   String serviceName, double serviceCost) {
        super(id, createdDate, updatedDate, hotelName, address, phoneNumber, email,
              roomNumber, roomType, pricePerNight,
              customerName, customerEmail, contactNumber,
              bookingDate, checkInDate, checkOutDate);
        if (isNullOrEmpty(serviceName)) {
            throw new IllegalArgumentException("serviceName must not be empty");
        }
        if (serviceCost <= 0) {
            throw new IllegalArgumentException("serviceCost must be > 0");
        }
        this.serviceName = serviceName;
        this.serviceCost = serviceCost;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        if (isNullOrEmpty(serviceName)) {
            throw new IllegalArgumentException("serviceName must not be empty");
        }
        this.serviceName = serviceName;
    }

    public double getServiceCost() {
        return serviceCost;
    }

    public void setServiceCost(double serviceCost) {
        if (serviceCost <= 0) {
            throw new IllegalArgumentException("serviceCost must be > 0");
        }
        this.serviceCost = serviceCost;
    }
}

// Payment
class Payment extends Service {
    private String paymentMethod;
    private String paymentDate;

    public Payment(int id, String createdDate, String updatedDate,
                   String hotelName, String address, String phoneNumber, String email,
                   String roomNumber, String roomType, double pricePerNight,
                   String customerName, String customerEmail, String contactNumber,
                   String bookingDate, String checkInDate, String checkOutDate,
                   String serviceName, double serviceCost,
                   String paymentMethod, String paymentDate) {
        super(id, createdDate, updatedDate, hotelName, address, phoneNumber, email,
              roomNumber, roomType, pricePerNight,
              customerName, customerEmail, contactNumber,
              bookingDate, checkInDate, checkOutDate,
              serviceName, serviceCost);
        if (isNullOrEmpty(paymentMethod) || isNullOrEmpty(paymentDate)) {
            throw new IllegalArgumentException("paymentMethod and paymentDate must not be empty");
        }
        this.paymentMethod = paymentMethod;
        this.paymentDate = paymentDate;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        if (isNullOrEmpty(paymentMethod)) {
            throw new IllegalArgumentException("paymentMethod must not be empty");
        }
        this.paymentMethod = paymentMethod;
    }

    public String getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(String paymentDate) {
        if (isNullOrEmpty(paymentDate)) {
            throw new IllegalArgumentException("paymentDate must not be empty");
        }
        this.paymentDate = paymentDate;
    }
}

// Bill
class Bill extends Payment {
    private double roomCharge;
    private double serviceCharge;
    private double totalBill;

    public Bill(int id, String createdDate, String updatedDate,
                String hotelName, String address, String phoneNumber, String email,
                String roomNumber, String roomType, double pricePerNight,
                String customerName, String customerEmail, String contactNumber,
                String bookingDate, String checkInDate, String checkOutDate,
                String serviceName, double serviceCost,
                String paymentMethod, String paymentDate,
                double roomCharge, double serviceCharge) {
        super(id, createdDate, updatedDate, hotelName, address, phoneNumber, email,
              roomNumber, roomType, pricePerNight,
              customerName, customerEmail, contactNumber,
              bookingDate, checkInDate, checkOutDate,
              serviceName, serviceCost,
              paymentMethod, paymentDate);
        if (roomCharge <= 0 || serviceCharge <= 0) {
            throw new IllegalArgumentException("roomCharge and serviceCharge must be > 0");
        }
        this.roomCharge = roomCharge;
        this.serviceCharge = serviceCharge;
        this.totalBill = 0.0;
    }

    public double getRoomCharge() {
        return roomCharge;
    }

    public void setRoomCharge(double roomCharge) {
        if (roomCharge <= 0) {
            throw new IllegalArgumentException("roomCharge must be > 0");
        }
        this.roomCharge = roomCharge;
    }

    public double getServiceCharge() {
        return serviceCharge;
    }

    public void setServiceCharge(double serviceCharge) {
        if (serviceCharge <= 0) {
            throw new IllegalArgumentException("serviceCharge must be > 0");
        }
        this.serviceCharge = serviceCharge;
    }

    public double getTotalBill() {
        return totalBill;
    }

    public void setTotalBill(double totalBill) {
        if (totalBill <= 0) {
            throw new IllegalArgumentException("totalBill must be > 0");
        }
        this.totalBill = totalBill;
    }
}

// Feedback
class Feedback extends Bill {
    private int rating; // 1-5
    private String comments;

    public Feedback(int id, String createdDate, String updatedDate,
                    String hotelName, String address, String phoneNumber, String email,
                    String roomNumber, String roomType, double pricePerNight,
                    String customerName, String customerEmail, String contactNumber,
                    String bookingDate, String checkInDate, String checkOutDate,
                    String serviceName, double serviceCost,
                    String paymentMethod, String paymentDate,
                    double roomCharge, double serviceCharge,
                    int rating, String comments) {
        super(id, createdDate, updatedDate, hotelName, address, phoneNumber, email,
              roomNumber, roomType, pricePerNight,
              customerName, customerEmail, contactNumber,
              bookingDate, checkInDate, checkOutDate,
              serviceName, serviceCost,
              paymentMethod, paymentDate,
              roomCharge, serviceCharge);
        if (rating < 1 || rating > 5) {
            throw new IllegalArgumentException("rating must be between 1 and 5");
        }
        if (isNullOrEmpty(comments)) {
            throw new IllegalArgumentException("comments must not be empty");
        }
        this.rating = rating;
        this.comments = comments;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        if (rating < 1 || rating > 5) {
            throw new IllegalArgumentException("rating must be between 1 and 5");
        }
        this.rating = rating;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        if (isNullOrEmpty(comments)) {
            throw new IllegalArgumentException("comments must not be empty");
        }
        this.comments = comments;
    }
}

// Final ReservationRecord
public final class ReservationRecord extends Feedback {

    public ReservationRecord(int id, String createdDate, String updatedDate,
                             String hotelName, String address, String phoneNumber, String email,
                             String roomNumber, String roomType, double pricePerNight,
                             String customerName, String customerEmail, String contactNumber,
                             String bookingDate, String checkInDate, String checkOutDate,
                             String serviceName, double serviceCost,
                             String paymentMethod, String paymentDate,
                             double roomCharge, double serviceCharge,
                             int rating, String comments) {
        super(id, createdDate, updatedDate, hotelName, address, phoneNumber, email,
              roomNumber, roomType, pricePerNight,
              customerName, customerEmail, contactNumber,
              bookingDate, checkInDate, checkOutDate,
              serviceName, serviceCost,
              paymentMethod, paymentDate,
              roomCharge, serviceCharge,
              rating, comments);
    }

    // generateBill() = roomCharge + serviceCharge
    public double generateBill() {
        double bill = getRoomCharge() + getServiceCharge();
        setTotalBill(bill);
        return bill;
    }
}
