package _26247_.question4;

import java.util.Scanner;

public class Question4Main {

    private static final String STUDENT_ID = "26247";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int maxAttempts = 3;

        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            try {
                runProgram(scanner);
                break;
            } catch (Exception ex) {
                printlnWithId("ERROR: " + ex.getMessage());
                if (attempt == maxAttempts) {
                    printlnWithId("Maximum attempts (" + maxAttempts + ") reached. Exiting program.");
                } else {
                    printlnWithId("Please re-enter all details carefully. Attempt "
                            + (attempt + 1) + " of " + maxAttempts + ".");
                }
            }
        }

        scanner.close();
    }

    private static void runProgram(Scanner scanner) {
        printlnWithId("=== Question 4: Hotel Reservation System ===");

        int entityId = readPositiveInt(scanner, "Enter Entity ID (integer > 0): ");
        String createdDate = readNonEmptyString(scanner, "Enter Created Date (e.g., 2025-11-22): ");
        String updatedDate = readNonEmptyString(scanner, "Enter Updated Date (e.g., 2025-11-22): ");

        String hotelName = readNonEmptyString(scanner, "Enter Hotel Name (non-empty text): ");
        String hotelAddress = readNonEmptyString(scanner, "Enter Hotel Address (non-empty text): ");
        String hotelPhone = readNonEmptyString(scanner, "Enter Hotel Phone Number (non-empty text): ");
        String hotelEmail = readEmail(scanner, "Enter Hotel Email (must contain @): ");

        String roomNumber = readNonEmptyString(scanner, "Enter Room Number (non-empty text): ");
        String roomType = readNonEmptyString(scanner, "Enter Room Type (non-empty text): ");
        double pricePerNight = readPositiveDouble(scanner,
                "Enter Price Per Night (number > 0): ");

        String customerName = readNonEmptyString(scanner, "Enter Customer Name (non-empty text): ");
        String customerEmail = readEmail(scanner, "Enter Customer Email (must contain @): ");
        String customerContact = readNonEmptyString(scanner,
                "Enter Customer Contact Number (non-empty text): ");

        String bookingDate = readNonEmptyString(scanner,
                "Enter Booking Date (e.g., 2025-11-22): ");
        String checkInDate = readNonEmptyString(scanner,
                "Enter Check-In Date (e.g., 2025-11-22): ");
        String checkOutDate = readNonEmptyString(scanner,
                "Enter Check-Out Date (e.g., 2025-11-22): ");

        String serviceName = readNonEmptyString(scanner, "Enter Service Name (non-empty text): ");
        double serviceCost = readPositiveDouble(scanner,
                "Enter Service Cost (number > 0): ");

        String paymentMethod = readNonEmptyString(scanner,
                "Enter Payment Method (e.g., Cash/Card): ");
        String paymentDate = readNonEmptyString(scanner,
                "Enter Payment Date (e.g., 2025-11-22): ");

        double roomCharge = readPositiveDouble(scanner,
                "Enter Room Charge (number > 0): ");
        double serviceCharge = readPositiveDouble(scanner,
                "Enter Service Charge (number > 0): ");

        int rating = readRating(scanner, "Enter Rating (1-5): ");
        String comments = readNonEmptyString(scanner, "Enter Comments (non-empty text): ");

        ReservationRecord record = new ReservationRecord(
                entityId, createdDate, updatedDate,
                hotelName, hotelAddress, hotelPhone, hotelEmail,
                roomNumber, roomType, pricePerNight,
                customerName, customerEmail, customerContact,
                bookingDate, checkInDate, checkOutDate,
                serviceName, serviceCost,
                paymentMethod, paymentDate,
                roomCharge, serviceCharge,
                rating, comments
        );

        double totalBill = record.generateBill();

        printlnWithId("=== Reservation Record Summary ===");
        printlnWithId("Entity ID: " + record.getId());
        printlnWithId("Hotel: " + record.getHotelName() + ", " + record.getAddress());
        printlnWithId("Room: " + record.getRoomNumber() + " (" + record.getRoomType()
                + ") at " + record.getPricePerNight() + " per night");
        printlnWithId("Customer: " + record.getCustomerName() + " (" + record.getCustomerEmail() + ")");
        printlnWithId("Booking: " + record.getBookingDate() + " | Check-in: " + record.getCheckInDate()
                + " | Check-out: " + record.getCheckOutDate());
        printlnWithId("Service: " + record.getServiceName() + " Cost: " + record.getServiceCost());
        printlnWithId("Room Charge: " + record.getRoomCharge());
        printlnWithId("Service Charge: " + record.getServiceCharge());
        printlnWithId("Total Bill: " + totalBill);
        printlnWithId("Rating: " + record.getRating() + " | Comments: " + record.getComments());
    }

    private static void printlnWithId(String msg) {
        System.out.println(msg + " [" + STUDENT_ID + "]");
    }

    private static void printWithId(String msg) {
        System.out.print(msg + " [" + STUDENT_ID + "] ");
    }

    private static int readPositiveInt(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            if (!scanner.hasNextInt()) {
                scanner.nextLine();
                printlnWithId("Invalid input: please enter a whole number > 0. Attempts left: " + (3 - attempt));
                continue;
            }
            int value = scanner.nextInt();
            scanner.nextLine();
            if (value > 0) {
                return value;
            }
            printlnWithId("Value must be > 0. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return 0;
    }

    private static double readPositiveDouble(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            if (!scanner.hasNextDouble()) {
                scanner.nextLine();
                printlnWithId("Invalid input: please enter a number > 0. Attempts left: " + (3 - attempt));
                continue;
            }
            double value = scanner.nextDouble();
            scanner.nextLine();
            if (value > 0) {
                return value;
            }
            printlnWithId("Value must be > 0. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return 0.0;
    }

    private static String readNonEmptyString(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            String value = scanner.nextLine();
            if (value != null && !value.trim().isEmpty()) {
                return value.trim();
            }
            printlnWithId("Input must not be empty. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return null;
    }

    private static String readEmail(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            String value = scanner.nextLine().trim();
            if (!value.isEmpty() && value.contains("@")) {
                return value;
            }
            printlnWithId("Invalid email: must contain '@'. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return null;
    }

    private static int readRating(Scanner scanner, String prompt) {
        for (int attempt = 1; attempt <= 3; attempt++) {
            printWithId(prompt);
            if (!scanner.hasNextInt()) {
                scanner.nextLine();
                printlnWithId("Invalid input: please enter an integer between 1 and 5. Attempts left: " + (3 - attempt));
                continue;
            }
            int rating = scanner.nextInt();
            scanner.nextLine();
            if (rating >= 1 && rating <= 5) {
                return rating;
            }
            printlnWithId("Rating must be between 1 and 5. Attempts left: " + (3 - attempt));
        }
        printlnWithId("Too many invalid attempts. Exiting.");
        System.exit(0);
        return 0;
    }
}
